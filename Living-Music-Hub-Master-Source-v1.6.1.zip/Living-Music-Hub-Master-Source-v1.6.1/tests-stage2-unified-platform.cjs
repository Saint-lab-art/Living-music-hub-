const fs = require('fs');
const path = require('path');
const root = __dirname;
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'hub-dashboard.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
const checks = [
  ['five division dashboard anchors exist', ['#discover','#studio','#design-studio','#movie-studio','#publishing-studio'].every(x => html.includes(`href="${x}"`))],
  ['dashboard module is loaded', html.includes('src="hub-dashboard.js"')],
  ['cloud workspace and project integration exists', js.includes("from('creative_workspaces')") && js.includes("from('creative_projects')")],
  ['private publishing draft integration exists', js.includes("from('publishing_works')") && js.includes("visibility:'private'") && js.includes("status:'draft'")],
  ['publishing rights confirmation is required', html.includes('name="rights_confirmed" type="checkbox" required') && js.includes('rights_confirmed:true')],
  ['uses existing publishable key and no service role', js.includes('SUPABASE_PUBLISHABLE_KEY') && !/service[_-]?role|sb_secret_/i.test(js)],
  ['responsive dashboard styling exists', css.includes('.hub-division-grid') && css.includes('@media(max-width:700px)')],
];
let failed = false;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`); if (!ok) failed = true; }
if (failed) process.exit(1);
