# Upload this source to GitHub safely

Repository: https://github.com/Saint-lab-art/Living-music-hub-
Target branch: `development/canonical-source-v1`
Base commit: `3eb31e5069afc9d0a46e4e54b9768102ffd81a81` (main, 20 Nov 2026)

1. Keep `main` unchanged.
2. Create `development/canonical-source-v1` from the base commit above.
3. Extract the contents of this package into the repository root on that branch, including hidden `.nojekyll`.
4. Commit the complete contents to that development branch only.
5. Review the GitHub Actions result and test the preview website.
6. Do not merge into `main` until all release gates are passed.

The connected GitHub integration returned HTTP 403 when asked to create a branch. An authorized repository collaborator must create the branch or the GitHub App's repository write permissions must be corrected. Never send passwords, personal access tokens or Supabase secrets through chat.
