# Living Music Hub — Master Source v1.6.1

**Status:** Canonical independent development master; not a production release.
**Prepared:** 23 November 2026

This is the selected, consolidated source package for the Living Music Hub five-division platform. It is based on the latest saved independent development source v1.6.1 Stage 5 Security Patch. The matching Cloudflare Preview Upload v1.6.1 archive was compared: its extracted application files match this source package.

## Five divisions
1. Music Platform
2. Music Production Studio
3. Photo & Picture Designing Studio
4. Movie & Video Production Studio
5. Writing & Publishing

## What is included
- Integrated browser application and Supabase client configuration using a browser-safe publishable key.
- Artist/listener account and music submission/review interfaces.
- Music studio multitrack, editing, mixer and WAV export foundations.
- Photo studio layered editing and PNG/JPG export foundations.
- Movie studio sequential timeline, trimming, project package and browser export foundations.
- Five-division dashboard, private writing/publishing workflow, AI assistant client interfaces and server-side AI function source.
- Private cloud-library client module, PWA assets, deployment headers, preflight checks and release documentation.

## Run local checks
Requires Node.js. From this folder run:

```bash
node deployment-preflight.cjs
for f in tests-*.cjs; do node "$f" || exit 1; done
for f in *.js; do node --check "$f" || exit 1; done
```

## Important release boundaries
- Static/source checks do not prove live operation.
- Supabase migration/function deployment, Auth configuration, real uploads, account/workspace isolation, payment processing and payout workflows are not certified by this package.
- AI interfaces and function source are included but AI is not activated until its migration, function, server-side provider secret, usage limits and owner-approved budget are configured and tested.
- Physical Android microphone, audio, photo, video, PWA and cross-browser tests remain outstanding.
- The included Content-Security-Policy is a starting policy and must be checked in a real preview browser; local checks do not establish browser compatibility.
- Do not put Supabase secret/service-role keys or OpenAI keys in browser files.

## Preservation and deployment
This master is a separate development artifact. Keep prior ZIPs and the existing production/original project unchanged. Use a separate preview deployment first. Do not publish to production, change Supabase settings, deploy migrations/functions, or rotate/revoke credentials without a separately approved release operation.
