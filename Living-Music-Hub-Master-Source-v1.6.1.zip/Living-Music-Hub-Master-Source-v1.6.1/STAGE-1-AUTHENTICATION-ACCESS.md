# Stage 1 — Foundation and authentication access

## Change in this build
- Added persistent **Sign in** and **Create account** shortcuts to the top header.
- Both shortcuts scroll to the existing account section, where the email/password sign-in and registration forms are located.
- Added compact Android/mobile header styling.
- Kept the existing Supabase authentication implementation and public publishable-key-only configuration unchanged.

## Important status
This is a source-package change only. It has not been deployed to a live hosting service, and it does not prove that Supabase registration, email confirmation, password reset, database permissions, or administrator access work end-to-end.

## Stage 1 verification still required
1. Open the updated app in a browser and confirm both header shortcuts are visible.
2. Tap **Sign in** and confirm the sign-in form is brought into view.
3. Tap **Create account** and confirm the registration form is brought into view.
4. Test registration, email confirmation, sign-in, password reset, sign-out and session persistence.
5. Grant administrator rights only after the owner account is created and email-verified; use the reviewed owner-only SQL procedure.
6. Verify database Row Level Security and Storage policies before opening uploads or moderation.

Never put a Supabase service-role/secret key in browser files.
