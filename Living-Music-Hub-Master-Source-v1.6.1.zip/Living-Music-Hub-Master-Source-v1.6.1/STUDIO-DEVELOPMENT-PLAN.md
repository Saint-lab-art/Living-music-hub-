# Living Music Hub — Studio Development Plan

## Approved direction
- Preserve the original application and main branch.
- Develop and test this separate studio version before any merge or public release.
- Provide both Easy Music Studio and Advanced Professional Studio.
- First priority: multitrack recording and editing.

## Included in this development build
- Easy / Advanced mode switch using the same recording engine.
- Existing microphone, piano, drum-pad and beat-sequencer tools.
- Separate vocal, piano and drum recordings.
- Visual arrangement lanes and clip start-position controls.
- Per-track arrangement mute and level controls.
- Synchronized arrangement playback.
- Stereo WAV arrangement export (up to five minutes per export in this initial mobile-friendly build).
- Local project save/load, including takes and arrangement settings.
- Expanded music genre choices including country, reggae, rock and rhumba.

## Next milestones
1. Test on Android Chrome and desktop browsers with real microphone recordings.
2. Add clip splitting, undo/redo and safer clip editing.
3. Add automation, effects and improved mixer routing.
4. Add cloud project sync only after local project reliability is verified.
5. Integrate approved exports with artist upload and moderation workflows.

## Safety / release rules
- Do not overwrite or merge into the original/main branch during development.
- Keep secrets out of source files; use only the Supabase publishable key in browser code.
- Do not distribute unreviewed uploads publicly.
- Do not claim deployment until the development branch has been successfully pushed and the hosted build tested.


## AI integration update — 21 November 2026
AI gateway source scaffold prepared for Photo image generation and Movie production-plan assistance. It includes authenticated user validation, a per-user daily usage ledger design, RLS migration, and frontend controls. Not deployed: no database migration applied, no Edge Function deployed, and no OpenAI secret configured. Actual AI features remain unavailable until the secure deployment and release tests are completed. AI video rendering, background removal and retouching are not part of this increment.
