const fs = require('fs');
const path = require('path');
const root = __dirname;
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
const js = fs.readFileSync(path.join(root,'cloud-library.js'),'utf8');
const css = fs.readFileSync(path.join(root,'styles.css'),'utf8');
const sw = fs.readFileSync(path.join(root,'sw.js'),'utf8');
const checks = [
 ['cloud upload form is present', html.includes('id="cloudAssetForm"')],
 ['file type and division selectors are present', html.includes('id="cloudAssetProject"') && html.includes('name="division"')],
 ['cloud module is loaded', html.includes('src="cloud-library.js"')],
 ['private creative bucket is used', js.includes("const BUCKET = 'lmh-creative-assets'")],
 ['workspace-scoped storage path is used', js.includes('`${workspace}/${user.id}/${crypto.randomUUID()}-${cleanName}`')],
 ['100 MB per-file client guard exists', js.includes('100 * 1024 * 1024')],
 ['MIME allowlist exists', js.includes('const TYPES = new Set')],
 ['file metadata is saved to creative_assets', js.includes("db.from('creative_assets').insert(row)")],
 ['signed URL is used for private file access', js.includes('createSignedUrl(item.storage_path,60)')],
 ['no public bucket URL is used', !js.includes('getPublicUrl(')],
 ['no secret key is embedded', !js.includes('service_role') && !js.includes('sb_secret_')],
 ['responsive cloud library styles exist', css.includes('.cloud-asset-form') && css.includes('@media(max-width:600px)')],
 ['service worker cache updated and includes module', sw.includes('unified-platform-v6') && sw.includes('./cloud-library.js')]
];
let failed=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);
console.log(`Stage 4 cloud library checks passed: ${checks.length}`);
