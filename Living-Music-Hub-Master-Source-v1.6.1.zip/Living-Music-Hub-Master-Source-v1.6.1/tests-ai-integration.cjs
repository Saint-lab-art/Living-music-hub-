const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const client = fs.readFileSync('studio-ai.js', 'utf8');
const edge = fs.readFileSync('supabase/functions/studio-ai/index.ts', 'utf8');
const sql = fs.readFileSync('supabase/migrations/202611210001_studio_ai_usage.sql', 'utf8');
const checks = [
  ['Photo AI controls exist', /id="photoAiGenerate"/.test(html) && /id="photoAiPrompt"/.test(html)],
  ['Movie AI controls exist', /id="movieAiAssist"/.test(html) && /id="movieAiOutput"/.test(html)],
  ['Client calls the authenticated Supabase Edge Function', /functions\.invoke\('studio-ai'/.test(client) && /getSession\(\)/.test(client)],
  ['Client contains no OpenAI secret', !/OPENAI_API_KEY|sk-[A-Za-z0-9_-]{16,}/.test(client)],
  ['Edge Function validates user session', /auth\.getUser\(token\)/.test(edge)],
  ['Edge Function enforces daily usage count', /studio_ai_usage/.test(edge) && /dailyLimit/.test(edge)],
  ['Edge Function uses server-side OpenAI key', /Deno\.env\.get\("OPENAI_API_KEY"\)/.test(edge)],
  ['Usage table enables RLS and restricts writes', /enable row level security/i.test(sql) && /revoke insert, update, delete/i.test(sql)],
  ['Image generation and Responses endpoints are configured', /v1\/images\/generations/.test(edge) && /v1\/responses/.test(edge)],
];
let failed = false;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`); if (!ok) failed = true; }
if (failed) process.exit(1);
