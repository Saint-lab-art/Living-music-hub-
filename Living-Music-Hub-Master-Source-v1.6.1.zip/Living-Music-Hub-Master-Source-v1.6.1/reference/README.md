# Reference-only source

`studio-v2.2-hardened.js` is retained from the newest 21 November 2026 studio package. It includes additional recorder and IndexedDB hardening. It is intentionally not the active `studio.js` because it is paired with an earlier page build and does not include all of the v3/v4 undo/redo interface hooks. Merge these changes only after a targeted compatibility review and tests.
