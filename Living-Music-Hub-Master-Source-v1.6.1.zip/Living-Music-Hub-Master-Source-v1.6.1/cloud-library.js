import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './config.js';

const db = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {auth:{persistSession:true,autoRefreshToken:true}});
const $ = id => document.getElementById(id);
const BUCKET = 'lmh-creative-assets';
const MAX_BYTES = 100 * 1024 * 1024;
const DIVISIONS = {music:'Music Platform',music_production:'Music Production',photo_design:'Photo & Picture Design',movie_production:'Movie Production',publishing:'Writing & Publishing'};
const TYPES = new Set(['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/quicktime','video/webm','audio/mpeg','audio/mp4','audio/aac','audio/wav','audio/ogg','audio/flac','application/pdf','text/plain','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.openxmlformats-officedocument.presentationml.presentation']);
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let user=null, workspace=null, projects=[];
function say(message,error=false){const n=$('cloudAssetStatus');if(n){n.textContent=message;n.classList.toggle('error',error)}}
function assetType(file){return file.type.startsWith('image/')?'image':file.type.startsWith('video/')?'video':file.type.startsWith('audio/')?'audio':'document'}
function formatSize(bytes){if(bytes<1024*1024)return `${Math.round(bytes/1024)} KB`;return `${(bytes/1024/1024).toFixed(1)} MB`}
async function loadProjects(){
 if(!workspace)return;
 const {data,error}=await db.from('creative_projects').select('id,title,division').eq('workspace_id',workspace).order('created_at',{ascending:false}).limit(100);
 if(error)throw error;projects=data||[];
 const select=$('cloudAssetProject');select.innerHTML='<option value="">General workspace file</option>'+projects.map(p=>`<option value="${esc(p.id)}">${esc(p.title)} · ${esc(DIVISIONS[p.division]||p.division)}</option>`).join('');
}
async function loadAssets(){
 if(!workspace)return;
 const {data,error}=await db.from('creative_assets').select('id,project_id,division,asset_type,storage_bucket,storage_path,file_name,mime_type,size_bytes,created_at').eq('workspace_id',workspace).order('created_at',{ascending:false}).limit(100);
 if(error)throw error;
 const list=$('cloudAssetList');
 if(!data?.length){list.innerHTML='<p class="hub-empty">No cloud files yet. Upload a project file to keep it in your private workspace.</p>';return;}
 list.innerHTML=data.map(a=>`<div class="hub-project-item cloud-asset-item"><div><b>${esc(a.file_name)}</b><small>${esc(DIVISIONS[a.division]||a.division)} · ${esc(a.asset_type)} · ${a.size_bytes?formatSize(a.size_bytes):'File'} · ${new Date(a.created_at).toLocaleDateString()}</small></div><button class="secondary cloud-open" type="button" data-asset="${esc(a.id)}">Open file</button></div>`).join('');
 list.querySelectorAll('[data-asset]').forEach(btn=>btn.addEventListener('click',async()=>{
  btn.disabled=true;try{const item=data.find(x=>x.id===btn.dataset.asset);if(!item)throw new Error('File not found.');const {data:signed,error}=await db.storage.from(item.storage_bucket).createSignedUrl(item.storage_path,60);if(error)throw error;window.location.assign(signed.signedUrl);}catch(e){say(e.message||'Could not open file.',true);}finally{btn.disabled=false;}
 }));
}
async function activate(sessionUser){
 user=sessionUser;
 let data=null,error=null;
 for(let attempt=0;attempt<5;attempt++){const result=await db.from('creative_workspaces').select('id').eq('owner_user_id',user.id).order('created_at',{ascending:true}).limit(1).maybeSingle();data=result.data;error=result.error;if(error)throw error;if(data)break;await new Promise(resolve=>setTimeout(resolve,250));}
 if(!data){say('Your workspace is still being prepared. Refresh My Hub and try again.',true);return;}
 workspace=data.id;$('cloudLibrarySignedOut').classList.add('hidden');$('cloudLibrarySignedIn').classList.remove('hidden');
 await loadProjects();await loadAssets();say('Private cloud storage connected.');
}
$('cloudAssetForm')?.addEventListener('submit',async e=>{
 e.preventDefault();if(!user||!workspace){say('Sign in and open your workspace first.',true);return;}
 const form=e.currentTarget, file=form.elements.file.files?.[0], division=form.elements.division.value, projectId=form.elements.project_id.value||null;
 if(!file){say('Choose a file first.',true);return;}if(file.size>MAX_BYTES){say('This file exceeds the 100 MB per-file limit for this upload form.',true);return;}if(!TYPES.has(file.type)){say('This file type is not supported. Use an image, audio, video, PDF, TXT, DOCX or PPTX file.',true);return;}
 const button=form.querySelector('button[type="submit"]');button.disabled=true;say('Uploading securely to your private workspace…');
 const cleanName=file.name.normalize('NFKD').replace(/[^a-zA-Z0-9._-]+/g,'_').slice(-120)||'creative-file';
 const path=`${workspace}/${user.id}/${crypto.randomUUID()}-${cleanName}`;
 try{
  const upload=await db.storage.from(BUCKET).upload(path,file,{contentType:file.type,upsert:false});if(upload.error)throw upload.error;
  const row={workspace_id:workspace,project_id:projectId,division,asset_type:assetType(file),storage_bucket:BUCKET,storage_path:path,file_name:file.name,mime_type:file.type,size_bytes:file.size,visibility:'private',metadata:{uploaded_from:'living_music_hub_web'},uploaded_by:user.id};
  const saved=await db.from('creative_assets').insert(row);if(saved.error){await db.storage.from(BUCKET).remove([path]);throw saved.error;}
  form.reset();say('File uploaded and saved in your private cloud library.');await loadAssets();
 }catch(err){say(err.message||'Upload failed. Please try again.',true);}finally{button.disabled=false;}
});
(async()=>{const {data}=await db.auth.getSession();if(data.session?.user){try{await activate(data.session.user);}catch(e){say(e.message||'Could not connect to cloud storage.',true);}}db.auth.onAuthStateChange((event,session)=>{if(session?.user)queueMicrotask(()=>activate(session.user).catch(e=>say(e.message||'Cloud library unavailable.',true)));else if(event==='SIGNED_OUT'){user=null;workspace=null;$('cloudLibrarySignedIn')?.classList.add('hidden');$('cloudLibrarySignedOut')?.classList.remove('hidden');say('Sign in to use your cloud library.');}});})();
