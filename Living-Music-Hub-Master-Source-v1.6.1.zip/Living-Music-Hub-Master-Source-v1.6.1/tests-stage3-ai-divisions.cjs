const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const client = fs.readFileSync('studio-ai.js', 'utf8');
const edge = fs.readFileSync('supabase/functions/studio-ai/index.ts', 'utf8');
const sql = fs.readFileSync('supabase/migrations/202611210001_studio_ai_usage.sql', 'utf8');
const checks = [
  ['Music Platform AI assistant UI exists', ['platformAiAssist','platformAiPrompt','platformAiOutput'].every(x => html.includes(`id="${x}"`))],
  ['Music Production AI assistant UI exists', ['musicAiAssist','musicAiPrompt','musicAiOutput'].every(x => html.includes(`id="${x}"`))],
  ['Photo Studio image generation UI remains', ['photoAiGenerate','photoAiPrompt','photoAiPreview'].every(x => html.includes(`id="${x}"`))],
  ['Movie Production assistant UI remains', ['movieAiAssist','movieAiPrompt','movieAiOutput'].every(x => html.includes(`id="${x}"`))],
  ['Writing & Publishing AI assistant UI exists', ['publishingAiAssist','publishingAiPrompt','publishingAiOutput'].every(x => html.includes(`id="${x}"`))],
  ['All five division actions are wired', ['music-platform-assist','music-production-assist','generate-image','production-assist','writing-assist'].every(x => client.includes(x))],
  ['Client invokes authenticated Supabase Edge Function', /functions\.invoke\('studio-ai'/.test(client) && /getSession\(\)/.test(client)],
  ['Client contains no provider or Supabase secret', !/OPENAI_API_KEY|SUPABASE_SERVICE_ROLE_KEY|SUPABASE_SECRET_KEYS|sk-[A-Za-z0-9_-]{16,}/.test(client)],
  ['Edge Function validates caller JWT', /auth\.getUser\(token\)/.test(edge)],
  ['Edge Function reads server-side OpenAI secret', /Deno\.env\.get\("OPENAI_API_KEY"\)/.test(edge)],
  ['Edge Function supports modern Supabase secret keys with legacy fallback', /SUPABASE_SECRET_KEYS/.test(edge) && /SUPABASE_SERVICE_ROLE_KEY/.test(edge)],
  ['Edge Function enforces per-user daily usage', /studio_ai_usage/.test(edge) && /dailyLimit/.test(edge)],
  ['Text assistant uses Responses API', /v1\/responses/.test(edge) && /gpt-6-luna/.test(edge)],
  ['Photo generation uses a current GPT Image model', /v1\/images\/generations/.test(edge) && /gpt-image-2\.6-flare/.test(edge)],
  ['Usage ledger covers all five divisions and restricts browser writes', /'music','music_production','photo','movie','publishing'/.test(sql) && /revoke insert, update, delete/i.test(sql) && /enable row level security/i.test(sql)],
];
let failed = false;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`); if (!ok) failed = true; }
if (failed) process.exit(1);
