# Stage 4 — Cloud Storage, Project Synchronisation and Creator Workflows

## Delivered in source package v1.5
- Added a private cloud library inside My Hub.
- Uploads image, audio, video, PDF, TXT, DOCX and PPTX files to the existing private `lmh-creative-assets` Supabase Storage bucket.
- Associates each uploaded file with one of the five approved divisions and optionally with a cloud project.
- Stores file metadata in `public.creative_assets` using the existing workspace-level RLS policies.
- Uses workspace/user-scoped object paths and short-lived signed URLs for private downloads.
- Adds a 100 MB per-file UI guard; the existing bucket allows up to 250 MB, and MIME restrictions are enforced by the bucket too.
- Adds responsive Android-friendly controls and includes the new module in the offline app shell.

## Existing backend verified before implementation
- Private `lmh-creative-assets` bucket already exists.
- Existing Storage RLS policies allow active workspace members with approved contributor roles to upload and update, workspace members to read, and workspace admins to delete.
- Existing `creative_assets` table already has workspace, project, division, file type, path, MIME, size, visibility and uploader fields, plus matching RLS policies.
- No new database migration is required for this stage.

## Important boundaries
- This stage does not deploy the site or change production database schema.
- Uploads require a signed-in account and a workspace created by My Hub.
- Cloud file access follows the existing workspace role policies. A member's exact permissions depend on their workspace role.
- This is file backup/synchronisation for uploaded assets; it does not yet synchronise every local DAW edit, browser recording, timeline state or unsaved project automatically.
- Large video/audio files consume storage and bandwidth and may incur Supabase charges. Confirm current project quotas and billing before broad public use.
- A successful source test does not replace live upload/download tests with separate user accounts and workspace roles.

## Stage 4 validation checklist
1. Sign in on Android and confirm My Hub creates/loads a workspace.
2. Upload one image, one audio file, one video and one document.
3. Confirm each file appears in the cloud library and opens through a signed link.
4. Sign in with a second workspace member and verify access is limited to that workspace.
5. Verify a user outside the workspace cannot list or open the files.
6. Test file size/type rejection and mobile network interruption behavior.
7. Review storage usage and backup/retention policy before launch.
