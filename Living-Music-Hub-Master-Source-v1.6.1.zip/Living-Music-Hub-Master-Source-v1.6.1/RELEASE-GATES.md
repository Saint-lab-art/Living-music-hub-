# Release gates — do not skip

## Before public launch
- [ ] Verify Supabase project ownership, URL and publishable key; no service-role key in browser code.
- [ ] Verify schema, foreign keys, indexes, Row Level Security and Storage policies against every query in `app.js`.
- [ ] Confirm admin role is enforced by database policies/server-side controls, not merely hidden UI.
- [ ] Test registration, email confirmation, sign-in, reset, sign-out and session refresh.
- [ ] Test artist profile create/update, audio upload limits, pending moderation, approve/reject, playback and takedown.
- [ ] Test favourites and signed audio URLs with two separate accounts.
- [ ] Test Stage 4 private cloud uploads for image/audio/video/documents; verify signed downloads and cross-workspace isolation with two accounts.
- [ ] Verify cloud library quota, retention, deletion/restore, storage billing and upload interruption behavior.
- [ ] Test multitrack capture, clip move/trim/split, undo/redo, project save/load and WAV export on Android Chrome and desktop.
- [ ] Test photo layers, drag editing, undo/redo, project save/load and PNG/JPG export on Android and desktop.
- [ ] Test video/audio import, timeline membership, trimming, ordering, sequence playback and MediaRecorder export on supported browsers; verify audio synchronisation and file-size limits.
- [ ] Test PWA install, offline fallback, cache update and recovery.
- [ ] Apply the reviewed `studio_ai_usage` migration, configure the OpenAI API key in Edge Function Secrets, deploy `studio-ai` with JWT verification enabled, and test all five AI assistants and daily limits.
- [ ] Review OpenAI API pricing and configure an owner-approved spend budget before enabling billable AI calls.
- [ ] Add privacy policy, terms, copyright/takedown process and content moderation procedures.
- [ ] Decide and document the video revenue share before payout code. Approved music revenue share is 65% creators / 35% platform. Books and articles are 75% author / 25% platform. Keep payouts subject to manual owner or authorised finance-officer approval.
- [ ] Implement and test payment processing, ledger, reconciliation and payout workflows before charging users.
- [ ] Complete backups, restore drill, monitoring, error logging and rollback plan.
- [ ] Run accessibility, security, dependency and end-to-end tests.
- [ ] Deploy to a separate preview environment and obtain release approval before merge to main.

## Known feature boundaries
- Music studio: multitrack foundation exists; effects racks, automation, cloud sync and collaboration remain future work.
- Photo studio: editable text/shape layers, image background, fit/fill, layer ordering, drag positioning, opacity/scale, undo/redo, JSON project files and PNG/JPG export exist; advanced retouching, crop handles, vector tools and templates remain. AI image-generation interface is prepared but not live until backend setup.
- Movie studio: sequential video lane, trim in/out, ordering, title overlay, imported audio bed, project package and browser recording export exist; independent audio timeline placement, full multitrack compositing, transitions, keyframes and GPU effects remain. AI production-plan assistant is prepared but not live until backend setup.


## Stage 5 deployment gates
- [ ] Run `node deployment-preflight.cjs` and resolve every failure.
- [ ] Deploy to a non-production HTTPS preview using manual ZIP/content upload; verify response headers.
- [ ] Configure exact Supabase Auth redirect URLs for preview and test full authentication lifecycle.
- [ ] Complete two-account/two-workspace isolation tests for database rows and private Storage objects.
- [ ] Complete Android Chrome and desktop browser regression tests for all five divisions.
- [ ] Verify backup and restore procedures for both database and Storage.
- [ ] Confirm legal, moderation, support, billing and incident-response readiness.
- [ ] Obtain explicit owner approval before production publication.
