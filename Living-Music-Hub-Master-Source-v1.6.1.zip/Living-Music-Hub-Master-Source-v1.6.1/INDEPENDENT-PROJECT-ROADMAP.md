# Living Music Hub — Independent Project Roadmap

## Project preservation
1. Keep the original project archive unchanged.
2. Treat this v4 package as the independent development line.
3. Keep dated ZIP backups on the user's device and a second cloud location. Gmail is suitable for backup records and links; Google Drive is better for storing the actual ZIP files.
4. Keep configuration secrets out of ZIPs intended for public hosting. Use server-side secrets for privileged backend operations.

## Product workstreams

### A. Music platform
- Listener discovery, search, playback, favourites and accounts.
- Artist profile submission, rights declaration, review queue, publish/reject, takedown and appeals.
- Secure audio storage and delivery; admin preview of pending submissions.
- Creator analytics, statements and transparent rights/credits.

### B. Music production studio
- Easy and Advanced modes; multitrack recording and editing.
- Next: physical-device testing, effects, automation, mixer routing, autosave and reliable project export.
- Later: cloud project sync and collaboration after local reliability and permissions are verified.

### C. Photo / picture designing studio
- Current foundation: image import, canvas presets, text overlay and PNG export.
- Next: crop, resize, layers, shapes, text styling, templates, undo/redo and editable project files.

### D. Movie production studio
- Current foundation: local footage bin, preview, clip ordering and storyboard notes.
- Next: multi-track timeline, clip trimming, audio tracks, title cards, transitions, captions, rendering and downloadable video export.
- Later: team review, cloud storage and creator publishing after rights and storage controls are implemented.

### E. Distribution and monetisation
- Music/video/download distribution, transparent usage reporting and rights management.
- Do not implement payout calculations until the revenue-share decision is reconciled. Approved music revenue share is 65% creators / 35% platform; books and articles are 75% author / 25% platform. Creator payouts require manual approval by the owner or an authorised finance officer.
- Marketplace commissions are separate and remain undecided.
- Core platform access remains free at launch; no subscription billing without a new explicit decision.

### F. Independent hosting and operations
- Select a non-GitHub host and configure domain, HTTPS, environment variables, backups and rollback.
- Verify backend policies and upload restrictions before exposing any creator uploads publicly.
- Test on Android Chrome and desktop browsers, including low-memory devices and weak network conditions.

## Release gates
A workstream is not complete until its user-facing behaviour, security, mobile compatibility, accessibility, error handling, backup/restore and end-to-end tests have been verified. Source-level checks alone are not a release certification.


## AI integration update — 21 November 2026
AI gateway source scaffold prepared for Photo image generation and Movie production-plan assistance. It includes authenticated user validation, a per-user daily usage ledger design, RLS migration, and frontend controls. Not deployed: no database migration applied, no Edge Function deployed, and no OpenAI secret configured. Actual AI features remain unavailable until the secure deployment and release tests are completed. AI video rendering, background removal and retouching are not part of this increment.


## Stage 3 — Creative divisions and AI services
Source interfaces and secure gateway prepared for all five divisions. The database usage ledger and Edge Function are not yet deployed. OpenAI API billing is separate from ChatGPT subscriptions; live AI activation requires owner budget review, secure secret configuration, migration, deployment and live tests.


## Stage 4 — Cloud storage and creator workflows
A private cloud library is now included in source v1.5, using the existing workspace-scoped Storage bucket and `creative_assets` RLS policies. It supports file uploads and signed downloads for all five divisions. Remaining work: live multi-account tests, file quota/billing review, network recovery, and future autosync for editable DAW/photo/video project state.


## Stage 5 — Deployment preparation and security
Static-host baseline headers, preflight checks, preview-first instructions, manual end-to-end verification and rollback guidance are included in source v1.6. Outstanding: deploy to a preview host, configure exact Supabase Auth redirect URLs, run two-account isolation tests and Android device checks, verify backups/restore and resolve all release-gate findings. Public production launch remains blocked until owner approval.
