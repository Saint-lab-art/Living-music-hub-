-- Per-user daily usage ledger for authenticated AI requests across all five divisions.
-- Apply only after review and before deploying the studio-ai Edge Function.
create table if not exists public.studio_ai_usage (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  studio text not null,
  action text not null,
  created_at timestamptz not null default now()
);

alter table public.studio_ai_usage drop constraint if exists studio_ai_usage_studio_check;
alter table public.studio_ai_usage drop constraint if exists studio_ai_usage_action_check;
alter table public.studio_ai_usage
  add constraint studio_ai_usage_studio_check
  check (studio in ('music','music_production','photo','movie','publishing'));
alter table public.studio_ai_usage
  add constraint studio_ai_usage_action_check
  check (action in ('generate-image','production-assist','music-platform-assist','music-production-assist','writing-assist'));

create index if not exists studio_ai_usage_user_action_created_idx
  on public.studio_ai_usage (user_id, action, created_at desc);

alter table public.studio_ai_usage enable row level security;
drop policy if exists "Users can read their own studio AI usage" on public.studio_ai_usage;
create policy "Users can read their own studio AI usage"
  on public.studio_ai_usage for select to authenticated
  using ((select auth.uid()) = user_id);
revoke insert, update, delete on public.studio_ai_usage from anon, authenticated;
grant select on public.studio_ai_usage to authenticated;
