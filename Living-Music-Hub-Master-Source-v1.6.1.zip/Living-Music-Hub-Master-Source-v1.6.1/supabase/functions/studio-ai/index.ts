// Living Music Hub — authenticated AI gateway for all five creative divisions.
// Keep verify_jwt enabled. OPENAI_API_KEY and Supabase secret keys belong only in Edge Function secrets.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" },
});
function getDefaultSecret(): string | null {
  const raw = Deno.env.get("SUPABASE_SECRET_KEYS");
  if (raw) {
    try { const keys = JSON.parse(raw); if (typeof keys.default === "string") return keys.default; } catch { /* fall through */ }
  }
  return Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || null;
}
const textAssistants: Record<string, { studio: string; instructions: string; dailyLimit: number }> = {
  "production-assist": {
    studio: "movie", dailyLimit: 10,
    instructions: "You are the Living Music Hub Movie Production assistant. Create a practical, clearly structured production plan with concept, logline, scene-by-scene storyboard, shot list, suggested dialogue or voice-over, locations, props, production checklist and editing notes. Do not claim to render or edit video files."
  },
  "music-platform-assist": {
    studio: "music", dailyLimit: 10,
    instructions: "You are the Living Music Hub Music Platform assistant. Help independent artists prepare truthful artist biographies, song and album descriptions, release announcements, audience profiles and ethical promotion plans. Do not invent awards, streams, endorsements, credentials or facts. Keep promotional copy original and clearly mark details the artist must verify."
  },
  "music-production-assist": {
    studio: "music_production", dailyLimit: 10,
    instructions: "You are the Living Music Hub Music Production assistant. Turn a song brief into an actionable production plan: musical direction, arrangement by section, tempo/key suggestions where appropriate, instrument and vocal recording plan, mixing checklist, mastering considerations and a practical session checklist. Provide creative guidance, not finished audio. Do not imitate a living artist; describe broad musical traits instead."
  },
  "writing-assist": {
    studio: "publishing", dailyLimit: 10,
    instructions: "You are the Living Music Hub Writing and Publishing assistant. Help users develop original outlines, chapter structures, article plans, research questions, editing suggestions and clear prose. Do not fabricate citations, quotations, data or sources. Flag facts requiring verification and distinguish suggestions from sourced evidence."
  }
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed." }, 405);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const secretKey = getDefaultSecret();
  const openAiKey = Deno.env.get("OPENAI_API_KEY");
  if (!supabaseUrl || !secretKey || !openAiKey) {
    return json({ error: "AI service is not configured yet. Contact the project administrator." }, 503);
  }

  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return json({ error: "Please sign in to use Living Music Hub AI." }, 401);

  // Validate the caller's Supabase session. Never trust a user ID supplied in the request body.
  const admin = createClient(supabaseUrl, secretKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: authData, error: authError } = await admin.auth.getUser(token);
  const user = authData?.user;
  if (authError || !user) return json({ error: "Your session is invalid or expired. Please sign in again." }, 401);

  const rawBody = await req.text();
  if (rawBody.length > 12000) return json({ error: "Request is too large." }, 413);
  let body: Record<string, unknown>;
  try { body = rawBody ? JSON.parse(rawBody) : {}; } catch { return json({ error: "Invalid JSON request." }, 400); }

  const action = String(body.action || "");
  const studio = String(body.studio || "");
  const prompt = String(body.prompt || "").trim();
  if (!prompt || prompt.length > 6000) return json({ error: "Enter a prompt of up to 6,000 characters." }, 400);

  const isImage = action === "generate-image" && studio === "photo";
  const textConfig = textAssistants[action];
  if (!isImage && (!textConfig || textConfig.studio !== studio)) {
    return json({ error: "That AI action is not available for this division." }, 400);
  }

  const dailyLimit = isImage
    ? Math.max(1, Math.min(10, Number(Deno.env.get("STUDIO_AI_DAILY_IMAGE_LIMIT") || "3")))
    : Math.max(1, Math.min(30, Number(Deno.env.get("STUDIO_AI_DAILY_TEXT_LIMIT") || String(textConfig.dailyLimit))));
  const since = new Date(); since.setUTCHours(0, 0, 0, 0);
  const { count, error: countError } = await admin.from("studio_ai_usage")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id).eq("action", action).gte("created_at", since.toISOString());
  if (countError) return json({ error: "AI usage controls are not ready. Please try again later." }, 503);
  if ((count || 0) >= dailyLimit) return json({ error: "You have reached today's request limit for this AI assistant. Please try again tomorrow." }, 429);

  let result: Record<string, unknown>;
  let upstream: Response;
  if (isImage) {
    upstream = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { "Authorization": `Bearer ${openAiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: Deno.env.get("OPENAI_IMAGE_MODEL") || "gpt-image-2.6-flare", prompt, n: 1, size: "1024x1024", output_format: "png" }),
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return json({ error: upstream.status === 429 ? "The image service is busy or its usage limit has been reached. Please try again later." : "Image generation failed. Please check the AI service configuration." }, upstream.status === 429 ? 429 : 502);
    const image = data?.data?.[0]?.b64_json;
    if (!image) return json({ error: "The image service returned no image." }, 502);
    result = { imageBase64: image, mimeType: "image/png", revisedPrompt: data?.data?.[0]?.revised_prompt || prompt };
  } else {
    upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${openAiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: Deno.env.get("OPENAI_TEXT_MODEL") || "gpt-6-luna",
        instructions: textConfig.instructions,
        input: prompt,
        max_output_tokens: 1800,
      }),
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return json({ error: upstream.status === 429 ? "The AI service is busy or its usage limit has been reached. Please try again later." : "AI assistance failed. Please check the AI service configuration." }, upstream.status === 429 ? 429 : 502);
    const outputText = (data?.output || []).flatMap((item: any) => item?.content || [])
      .filter((part: any) => part?.type === "output_text").map((part: any) => part.text).join("\n").trim();
    if (!outputText) return json({ error: "The AI service returned an empty response." }, 502);
    result = { text: outputText };
  }

  const { error: logError } = await admin.from("studio_ai_usage").insert({ user_id: user.id, studio, action });
  if (logError) return json({ error: "The result was generated, but usage could not be recorded. Please contact support before retrying." }, 503);
  return json({ ...result, remainingToday: Math.max(0, dailyLimit - (count || 0) - 1) });
});
