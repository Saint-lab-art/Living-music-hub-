# Stage 5 — Deployment Preparation, Live-Test Readiness & Security

## What this stage delivers
- Static-host security headers in `_headers` (supported by Cloudflare Pages and Netlify-style static hosting).
- A repeatable pre-deployment audit script that checks required app-shell files, release notes, service-worker cache consistency, and obvious secret-key mistakes.
- A preview-first deployment runbook for an independent static host; no GitHub connection is required.
- A live acceptance checklist covering Android Chrome, authentication, workspace isolation, uploads/downloads, PWA updates, AI and rollback.

## Important status
This is deployment preparation, not a live deployment. No production hosting account has been connected or changed. No production database or Storage policies have been modified. Browser-only automated checks cannot prove that live authentication, RLS, file isolation, payments, or media editing work correctly.

## Hosting approach
The application is a static web app. It can be deployed to a static host that supports HTTPS, ES modules, service workers, and custom response headers. The `_headers` file is provided for hosts that implement the Netlify/Cloudflare Pages `_headers` convention. If another host is selected, translate these rules into that host's header configuration and verify the resulting response headers.

### Preview-first procedure
1. Keep the original ZIP and all earlier stage ZIPs unchanged.
2. Extract this Stage 5 ZIP into a new folder.
3. Upload the extracted project folder contents to a **preview/staging** static site using the host's direct-upload/dashboard workflow. Do not select a GitHub-connected workflow.
4. Enable HTTPS and ensure the host serves `index.html` at the site root. Confirm `_headers` is applied.
5. Open the preview URL in Android Chrome. Do not use `file://`.
6. Run every relevant item in `LIVE-ACCEPTANCE-TESTS-STAGE-5.md` with two separate test accounts where indicated.
7. Record failures and fix them before any public launch. Keep public registration closed or clearly marked as test-only until access controls are verified.
8. Only after the owner reviews the results should a production site be created or updated.

## Configuration and secrets
- `config.js` contains a browser publishable/anon key and project URL. A publishable key is not a secret, but it must be protected by correct Supabase RLS and Storage policies.
- Never place a Supabase `service_role` key, database password, OpenAI API key, payment secret, or other server secret in HTML, JavaScript, a ZIP intended for public hosting, or browser storage.
- OpenAI API credentials belong only in Supabase Edge Function Secrets. The AI function is not considered live until securely deployed and tested.
- Confirm the Supabase project URL and publishable key belong to the intended project before launch. Do not rotate or replace credentials as part of this preparation stage.

## Security-header note
The included CSP permits the current app's Supabase and esm.sh module dependencies and allows inline styles used by the existing interface. It is a practical starting policy, not a substitute for a browser security review. Verify the browser console on the preview host. If a required feature is blocked, identify the exact dependency and make the narrowest necessary change; do not broadly add `unsafe-eval` or `*` sources.

## Operational controls still required
- Privacy policy, terms of use, copyright/takedown and moderation procedures.
- Owner-controlled admin role assignment and verified database enforcement.
- Supabase quota, retention, backup and restore review.
- AI API budget approval and server-side usage controls before AI activation.
- Payment provider, ledger, reconciliation and manual payout approval tests before accepting money.
- Written decision on any future movie/video creator revenue share; no video split is assumed here.
- Monitoring, incident contact, backup schedule and rollback procedure.

## Rollback
Keep the last known-good deployed static bundle and its ZIP. If a release breaks sign-in, uploads, navigation or editing, restore the previous bundle using the hosting dashboard's deployment rollback or re-upload workflow. Do not delete the Supabase project or Storage bucket as a rollback measure. Database migrations, if any are introduced later, need a separate reviewed rollback plan.
