import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './config.js';

const db = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
const el = id => document.getElementById(id);
const divisions = {music:'Music Platform',music_production:'Music Production',photo_design:'Photo & Picture Design',movie_production:'Movie Production',publishing:'Writing & Publishing'};
const safe = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let activeUser = null, workspaceId = null;
function status(id, message, error=false){const node=el(id);if(node){node.textContent=message;node.classList.toggle('error',error)}}
function showSignedIn(yes){el('hubSignedOut')?.classList.toggle('hidden',yes);el('hubSignedIn')?.classList.toggle('hidden',!yes);el('publishingSignedOut')?.classList.toggle('hidden',yes);el('publishingSignedIn')?.classList.toggle('hidden',!yes);el('hubConnection').textContent=yes?'Workspace connected':'Sign in to sync'}
async function ensureWorkspace(user){
 let {data,error}=await db.from('creative_workspaces').select('id,name').eq('owner_user_id',user.id).order('created_at',{ascending:true}).limit(1).maybeSingle();
 if(error) throw error;
 if(data){workspaceId=data.id;el('hubWorkspaceName').textContent=data.name;return data;}
 const created=await db.from('creative_workspaces').insert({owner_user_id:user.id,name:'My Living Music Hub Workspace',workspace_type:'personal',description:'Personal workspace shared across the five Living Music Hub divisions.'}).select('id,name').single();
 if(created.error) throw created.error; workspaceId=created.data.id;el('hubWorkspaceName').textContent=created.data.name;return created.data;
}
async function loadProjects(){
 if(!workspaceId)return; const {data,error}=await db.from('creative_projects').select('id,title,division,status,created_at').eq('workspace_id',workspaceId).order('created_at',{ascending:false}).limit(30);
 if(error) throw error; const target=el('hubProjectList');
 if(!data?.length){target.innerHTML='<p class="hub-empty">No cloud projects yet. Create your first project above. Existing local studio files remain on your device until uploaded.</p>';return;}
 target.innerHTML=data.map(p=>`<div class="hub-project-item"><div><b>${safe(p.title)}</b><small>${safe(divisions[p.division]||p.division)} · ${safe(p.status)} · ${new Date(p.created_at).toLocaleDateString()}</small></div></div>`).join('');
}
async function loadPublishing(){
 const {data,error}=await db.from('publishing_works').select('id,title,work_type,status,created_at').eq('author_user_id',activeUser.id).order('created_at',{ascending:false}).limit(30);
 if(error) throw error;const target=el('publishingList');if(!data?.length){target.innerHTML='<p class="hub-empty">No writing projects saved yet.</p>';return;}
 target.innerHTML=data.map(w=>`<div class="hub-project-item"><div><b>${safe(w.title)}</b><small>${safe(w.work_type)} · ${safe(w.status)} · ${new Date(w.created_at).toLocaleDateString()}</small></div></div>`).join('');
}
async function activate(user){activeUser=user;showSignedIn(true);el('hubUserLabel').textContent=user.email||'Signed in';try{await ensureWorkspace(user);await Promise.all([loadProjects(),loadPublishing()]);}catch(e){status('hubProjectStatus',e.message||'Could not load your workspace. Check your account permissions.',true);status('publishingStatus',e.message||'Could not load writing projects.',true);}}
async function deactivate(){activeUser=null;workspaceId=null;showSignedIn(false);el('hubProjectList').innerHTML='<p class="muted">Sign in to view cloud projects.</p>';el('publishingList').innerHTML='<p class="muted">Sign in to view writing projects.</p>';el('hubUserLabel').textContent='';}
el('hubProjectForm')?.addEventListener('submit',async event=>{event.preventDefault();if(!activeUser||!workspaceId)return;const form=new FormData(event.currentTarget);const title=String(form.get('title')||'').trim();const division=String(form.get('division')||'');if(!title)return;const button=event.currentTarget.querySelector('button[type="submit"]');button.disabled=true;status('hubProjectStatus','Creating project…');try{const {error}=await db.from('creative_projects').insert({workspace_id:workspaceId,division,title,created_by:activeUser.id,status:'draft'});if(error)throw error;event.currentTarget.reset();status('hubProjectStatus','Project created in your shared workspace.');await loadProjects();}catch(e){status('hubProjectStatus',e.message||'Project could not be created.',true);}finally{button.disabled=false;}});
el('publishingForm')?.addEventListener('submit',async event=>{event.preventDefault();if(!activeUser)return;const form=new FormData(event.currentTarget);const title=String(form.get('title')||'').trim();const rights=form.get('rights_confirmed')==='on';if(!title||!rights)return;const button=event.currentTarget.querySelector('button[type="submit"]');button.disabled=true;status('publishingStatus','Saving private draft…');try{const {error}=await db.from('publishing_works').insert({workspace_id:workspaceId,author_user_id:activeUser.id,work_type:String(form.get('work_type')||'other'),title,abstract:String(form.get('abstract')||''),status:'draft',visibility:'private',currency:'ZMW',price:0,rights_confirmed:true,rights_confirmed_at:new Date().toISOString()});if(error)throw error;event.currentTarget.reset();status('publishingStatus','Private draft saved successfully.');await loadPublishing();}catch(e){status('publishingStatus',e.message||'Could not save the draft.',true);}finally{button.disabled=false;}});
(async()=>{const {data,error}=await db.auth.getSession();if(error){status('hubProjectStatus',error.message,true);return;}if(data.session?.user)await activate(data.session.user);else deactivate();db.auth.onAuthStateChange((event,session)=>{if(session?.user)queueMicrotask(()=>activate(session.user));else if(event==='SIGNED_OUT')queueMicrotask(deactivate);});})();
