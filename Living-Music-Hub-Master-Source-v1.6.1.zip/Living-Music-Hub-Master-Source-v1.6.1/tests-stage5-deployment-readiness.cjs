const fs = require('fs');
const path = require('path');
const root = __dirname;
let passed = 0, failed = 0;
function check(name, ok) { if (ok) { passed++; console.log(`PASS ${name}`); } else { failed++; console.error(`FAIL ${name}`); } }
const required = ['index.html','app.js','config.js','studio.js','photo-video.js','studio-ai.js','hub-dashboard.js','cloud-library.js','styles.css','manifest.webmanifest','sw.js','_headers','DEPLOYMENT-PREPARATION-STAGE-5.md','LIVE-ACCEPTANCE-TESTS-STAGE-5.md'];
for (const file of required) check(`required file: ${file}`, fs.existsSync(path.join(root,file)));
const sw = fs.readFileSync(path.join(root,'sw.js'),'utf8');
for (const file of ['index.html','styles.css','app.js','config.js','studio.js','photo-video.js','studio-ai.js','hub-dashboard.js','cloud-library.js','manifest.webmanifest','icon.svg','icon-192.png','icon-512.png']) check(`service worker app shell includes ${file}`, sw.includes(`'./${file}'`));
const headers = fs.readFileSync(path.join(root,'_headers'),'utf8');
for (const h of ['Content-Security-Policy','X-Content-Type-Options','Referrer-Policy','Permissions-Policy','Strict-Transport-Security']) check(`security header configured: ${h}`, headers.includes(h));
const sourceFiles = fs.readdirSync(root).filter(f => /\.(js|html|json|sql)$/i.test(f));
let source = sourceFiles.map(f => fs.readFileSync(path.join(root,f),'utf8')).join('\n');
const secretPatterns = [/service_role\s*['"=:]/i,/sk-[A-Za-z0-9]{20,}/,/OPENAI_API_KEY\s*=\s*['"][^'"]+['"]/i,/postgres(?:ql)?:\/\/[^\s'"`]+:[^\s'"`]+@/i];
for (const pattern of secretPatterns) check(`no obvious embedded secret pattern ${pattern}`, !pattern.test(source));
check('release checklist exists', fs.existsSync(path.join(root,'RELEASE-GATES.md')));
check('stage 5 version documented', fs.readFileSync(path.join(root,'SOURCE-VERSION.md'),'utf8').includes('Stage 5'));
console.log(`\nStage 5 readiness checks: ${passed} passed, ${failed} failed.`);
process.exitCode = failed ? 1 : 0;
