import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './config.js';

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});
const $ = (id) => document.getElementById(id);
const setStatus = (id, message, error = false) => {
  const node = $(id); if (!node) return;
  node.textContent = message; node.classList.toggle('error', error);
};
async function invoke(action, studio, prompt) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Please sign in to use Living Music Hub AI.');
  const { data, error } = await supabase.functions.invoke('studio-ai', { body: { action, studio, prompt } });
  if (error) {
    let message = error.message || 'AI request failed.';
    try { const context = error.context; if (context?.json) { const body = await context.json(); message = body.error || message; } } catch {}
    throw new Error(message);
  }
  if (data?.error) throw new Error(data.error);
  return data;
}
function wireTextAssistant({buttonId,promptId,statusId,outputId,studio,action,emptyMessage,successMessage}) {
  const button=$(buttonId); if(!button)return;
  button.addEventListener('click',async()=>{
    const prompt=$(promptId)?.value.trim();
    if(!prompt){setStatus(statusId,emptyMessage,true);return;}
    button.disabled=true;setStatus(statusId,'Preparing your AI-assisted content…');
    try{
      const data=await invoke(action,studio,prompt);
      const output=$(outputId);output.textContent=data.text||'No text was returned.';output.hidden=false;
      setStatus(statusId,successMessage||`Completed. ${data.remainingToday} request(s) remain today.`);
    }catch(error){setStatus(statusId,error.message,true);}
    finally{button.disabled=false;}
  });
}

const photoButton = $('photoAiGenerate');
if (photoButton) photoButton.addEventListener('click', async () => {
  const prompt = $('photoAiPrompt').value.trim();
  if (!prompt) return setStatus('photoAiStatus', 'Describe the image you want to create.', true);
  photoButton.disabled = true; setStatus('photoAiStatus', 'Creating your image…');
  try {
    const data = await invoke('generate-image', 'photo', prompt);
    const url = `data:${data.mimeType || 'image/png'};base64,${data.imageBase64}`;
    const preview = $('photoAiPreview'); preview.src = url; preview.hidden = false;
    const download = $('photoAiDownload'); download.href = url; download.hidden = false;
    setStatus('photoAiStatus', `Image created. ${data.remainingToday} image request(s) remain today. Download it, then import it into the Photo Studio canvas.`);
  } catch (error) { setStatus('photoAiStatus', error.message, true); }
  finally { photoButton.disabled = false; }
});

wireTextAssistant({buttonId:'platformAiAssist',promptId:'platformAiPrompt',statusId:'platformAiStatus',outputId:'platformAiOutput',studio:'music',action:'music-platform-assist',emptyMessage:'Describe your artist, music or release first.'});
wireTextAssistant({buttonId:'musicAiAssist',promptId:'musicAiPrompt',statusId:'musicAiStatus',outputId:'musicAiOutput',studio:'music_production',action:'music-production-assist',emptyMessage:'Describe your song idea first.'});
wireTextAssistant({buttonId:'publishingAiAssist',promptId:'publishingAiPrompt',statusId:'publishingAiStatus',outputId:'publishingAiOutput',studio:'publishing',action:'writing-assist',emptyMessage:'Describe your writing project first.'});

const movieButton = $('movieAiAssist');
if (movieButton) movieButton.addEventListener('click', async () => {
  const brief = $('movieAiPrompt').value.trim();
  if (!brief) return setStatus('movieAiStatus', 'Describe your movie, advert, music video or documentary idea.', true);
  const notes = $('movieNotes')?.value.trim() || '';
  const prompt = `Production brief:\n${brief}\n\nExisting project notes (if any):\n${notes || 'None'}\n\nCreate a practical production plan with a concept, logline, scene-by-scene storyboard, shot list, suggested dialogue/voice-over, locations/props, and editing notes.`;
  movieButton.disabled = true; setStatus('movieAiStatus', 'Preparing your production plan…');
  try {
    const data = await invoke('production-assist', 'movie', prompt);
    const output = $('movieAiOutput'); output.textContent = data.text; output.hidden = false;
    setStatus('movieAiStatus', `${data.remainingToday} production-assistant request(s) remain today.`);
    const add = $('movieAiAddNotes'); add.hidden = false;
  } catch (error) { setStatus('movieAiStatus', error.message, true); }
  finally { movieButton.disabled = false; }
});
$('movieAiAddNotes')?.addEventListener('click', () => {
  const notes = $('movieNotes'); const output = $('movieAiOutput');
  if (!notes || !output) return;
  notes.value = `${notes.value.trim()}${notes.value.trim() ? '\n\n' : ''}AI PRODUCTION PLAN\n${output.textContent}`;
  setStatus('movieAiStatus', 'Production plan added to your project notes. Save the movie project to keep it.');
});
