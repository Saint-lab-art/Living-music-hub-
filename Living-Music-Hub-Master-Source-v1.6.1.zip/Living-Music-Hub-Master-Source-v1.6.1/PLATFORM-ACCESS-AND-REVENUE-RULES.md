# Living Music Hub — Access, Entitlements and Revenue Rules

Status: approved product requirements; backend enforcement and financial processing remain to be implemented and independently tested.

## 1. Subscription decision
- No subscription plans or subscription billing at launch.
- Core access is free for listeners, registered users, artists, producers and video creators.
- Do not introduce paywalls for core listening, core Studio access, account registration or artist applications.
- Build an entitlement model that can be extended later, but set the launch subscription state to `not_required` and do not create recurring charges.
- Any future paid tier requires a separate product decision and explicit user approval before activation.

## 2. Account and role model
Use one account identity per person. A user begins with the ordinary `member` role. Additional roles are granted through separate workflows: `artist`, `producer`, `video_creator` and `admin`. A person may hold multiple approved roles. Studio access is available to ordinary registered users and artists. Administrative privileges are manually granted and never self-selected during registration.

Creating music does not itself grant copyright ownership or distribution authority. Authorization must be enforced by trusted server/database policies, not by hiding buttons or trusting browser-supplied role values. Users may read and change only their own profile and permitted content. Administrative actions require explicit privileged authorization and audit records.

## 3. Free core access and configurable capacity limits
Core features remain free. Operational limits may protect infrastructure and prevent abuse, including maximum audio/video upload size and formats, storage quota and project count, video duration/resolution, processing queue capacity, upload rate limits, concurrent jobs, and abuse controls. Limits must be transparent, configurable by authorized administrators, applied consistently, and must not silently become subscription paywalls. A limit reached should explain what happened and how the user can manage files or request support.

## 4. Creator publishing permissions
Artist profile creation is not the same as verification or approval to publish. Use explicit states such as `draft`, `submitted`, `under_review`, `verified`, `rejected` and `needs_information`. Store reviewer, timestamps and reasons. Only authorized, approved submissions may be published. Rights declarations, duplicate checks, content validation and takedown workflows are required.

## 5. Music revenue sharing
For distributable revenue from music streaming, music videos and paid music downloads: Artist share 65%; Living Music Hub share 35%. The calculation base must be disclosed. Taxes, refunds, chargebacks, provider fees and other permitted adjustments must be consistently defined and recorded. Example: K1,000 distributable revenue results in K650 artist share and K350 platform share.

Use a server-side, append-only financial ledger as the source of truth. Use decimal-safe currency arithmetic, idempotent event processing, reconciliation, compensating entries for corrections, and immutable audit history. Never calculate authoritative balances only in the browser or silently edit/delete posted financial entries.

Artist balances must distinguish pending, available, reserved and lifetime paid amounts. Minimum withdrawal is K100; payout cycle is weekly; payout approval is hybrid. A payout is not `paid` until the payment provider confirms it and reconciliation is complete. Failed, reversed and duplicate transfers must be handled without losing or double-counting funds.

## 6. Marketplace and collaboration revenue
Marketplace service orders are separate from streaming, video and download revenue. Marketplace commission/fees remain undecided and must not default to 65/35. Customers and providers must agree to scope, price, delivery, revisions, deadlines and cancellation/refund terms before work begins. Do not describe the payment flow as escrow unless legal and payment-provider arrangements actually support safeguarded funds.

Collaboration ownership, credits, permissions and revenue splits are distinct. Participants negotiate and record their own agreements; no default collaborator split is implied. Resolve rights disputes before releasing disputed earnings.

## 7. Voluntary NAPSA contribution feature
When an artist's actual monthly 65% share reaches K3,500 or more, show an optional voluntary contribution feature. Reaching the threshold does not trigger a deduction. The artist chooses an amount and explicitly confirms each contribution, and may stop future contributions. Distinguish amounts processed by LMH from amounts officially credited by NAPSA; show NAPSA credit only after authoritative confirmation. Confirm legal obligations, authorisation and remittance arrangements before launch; voluntary treatment must not be used to avoid statutory employer obligations.

## 8. Implementation boundary
The present Studio development package is a browser application with a Supabase client. It does not yet contain the complete server-side role schema, financial ledger, payment-provider integrations, marketplace settlement system or NAPSA remittance integration. Those components must be delivered through reviewed database migrations, server-side functions, access policies and end-to-end tests before any corresponding feature is described as operational.
