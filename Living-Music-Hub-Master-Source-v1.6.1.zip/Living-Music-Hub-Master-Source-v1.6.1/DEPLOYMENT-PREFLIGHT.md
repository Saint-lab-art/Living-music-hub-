# Stage 5 — Deployment Preparation and Security

## What this package is
A static web application source package with Supabase browser connectivity. Stage 5 adds deployment preflight checks, baseline response headers and a practical live-test/rollback plan. It is **not deployed** and passing local checks is not proof of production readiness.

## Hosting approach (independent of GitHub)
Use a static HTTPS host that supports direct ZIP/manual upload and honours a root `_headers` file (for example, Cloudflare Pages direct upload or Netlify manual deploy). Upload the **contents** of this extracted project folder so `index.html` is at the published root. Do not upload the ZIP as the website itself. Keep the Supabase backend separate.

1. Preserve the Stage 4 ZIP as an untouched backup.
2. Extract this Stage 5 ZIP on the Android device or a computer.
3. Run `node deployment-preflight.cjs` in the extracted folder before upload (requires Node.js; this is optional but recommended).
4. Create a **preview/staging** site first. Do not use the public production domain for the first test.
5. Enable HTTPS and confirm the host serves the `_headers` file rules. The provided headers are a baseline; review host-specific behaviour.
6. Confirm the existing Supabase URL and publishable key in `config.js` are the intended project values. A publishable key is intended for browser use; never replace it with a secret/service-role key.
7. Configure Supabase Auth's allowed site URL and redirect URLs for the exact preview hostname, then test sign-up, email confirmation, sign-in, sign-out and password reset. Add the production hostname only after preview passes.
8. Test with two separate accounts and at least two workspaces before accepting uploads or creator content.
9. Only after all release gates pass, obtain explicit owner approval before publishing to the production hostname.

## Secrets and billing
- Never put `sb_secret_...`, a legacy service-role JWT, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_SECRET_KEYS`, or `OPENAI_API_KEY` in `config.js`, HTML, JavaScript, ZIP files, or hosting static-site variables exposed to the browser.
- The OpenAI key belongs only in Supabase Edge Function Secrets. Stage 3 AI is not activated by this package.
- The Supabase publishable key is visible to browsers by design. Security depends on Auth, RLS, Storage policies and server-side authorization—not hiding that key.
- Check Supabase storage, bandwidth, database and function usage/billing before inviting real users. Do not assume a free quota is sufficient.
- Payments, creator payouts and subscription billing are not enabled by this stage. Preserve the approved music 65/35 and books/articles 75/25 splits; payouts still require manual owner/authorised finance approval.

## Manual release test sequence
- [ ] Open the HTTPS preview on Android Chrome and desktop Chrome/Firefox/Edge.
- [ ] Confirm the home page, all five division links and My Hub load without console errors.
- [ ] Register a test account; confirm email; sign in; refresh; sign out; reset password.
- [ ] Confirm a new account cannot grant itself administrator, finance or moderation privileges.
- [ ] Test workspace creation, project creation and membership/role restrictions.
- [ ] Upload and download a small image, audio, video and PDF in the private cloud library.
- [ ] Confirm account B cannot view, download, edit or delete account A's private files or workspace assets.
- [ ] Test interrupted upload, retry, unsupported file, over-limit file and expired signed URL.
- [ ] Test music submission/moderation, playback, favourites and rights/takedown workflow.
- [ ] Test music recording/export, photo project save/load/export and movie preview/export on the actual Android device.
- [ ] Test PWA install, cache refresh and offline fallback. Verify a new release is not stuck behind an old service-worker cache.
- [ ] Check privacy policy, terms, copyright/takedown process, content moderation, contact/support and data retention before public launch.
- [ ] Verify backup and restore of database configuration/data and storage assets; document who can restore them.
- [ ] Review Supabase security/performance advisors and logs; resolve critical/high issues.
- [ ] Keep AI disabled until its migration, Edge Function, server-side key, usage limits, cost alerts and owner-approved budget are all verified.

## Rollback
Keep the previous known-good ZIP and its deployment available. If a release causes login, permissions, upload or data-integrity problems, restore the previous static-site release, disable affected upload/AI entry points if necessary, preserve logs, and investigate before redeploying. A static-site rollback does not roll back Supabase database migrations or user uploads; database/storage recovery needs its own tested backup plan.

## Known limitations
The supplied `_headers` file now includes a baseline Content-Security-Policy allowing the current Supabase JS module source (`esm.sh`), Supabase HTTPS/WebSocket endpoints, same-origin assets, and the browser media workflows. This policy has passed source-level checks only; it has not been verified in a live browser. On the HTTPS preview, inspect the actual response headers and browser console, then test sign-in, uploads, playback, recording, photo export, movie preview/export and PWA behavior. If a required feature is blocked, identify the exact dependency and make the narrowest change; do not broadly add `unsafe-eval` or wildcard sources. Host support for `_headers` varies.
