// Dependency-free smoke tests for the multitrack edit helpers.
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(__dirname + '/studio.js', 'utf8').replace(/\ninit\(\);?\s*$/, '\n');
const context = vm.createContext({
  console, Blob, Date, Math, Number, Object, String,
  setTimeout, clearTimeout,
  document: { getElementById: () => null },
});
vm.runInContext(source, context, { filename: 'studio.js' });
const run = (code) => vm.runInContext(code, context);
run("studio.trackTakes.vocals=[{blob:new Blob(['audio']),duration:10,trimStart:0,trimEnd:10,startAt:2}];");
run("splitTake('vocals',0,4);");
const split = run("({count:studio.trackTakes.vocals.length,leftEnd:studio.trackTakes.vocals[0].trimEnd,rightStart:studio.trackTakes.vocals[1].trimStart,rightTimelineStart:studio.trackTakes.vocals[1].startAt})");
if (split.count !== 2 || split.leftEnd !== 4 || split.rightStart !== 4 || split.rightTimelineStart !== 6) throw new Error('Split test failed: ' + JSON.stringify(split));
run('undoStudioEdit();');
const undone = run("({count:studio.trackTakes.vocals.length,end:studio.trackTakes.vocals[0].trimEnd})");
if (undone.count !== 1 || undone.end !== 10) throw new Error('Undo test failed: ' + JSON.stringify(undone));
run('redoStudioEdit();');
const redone = run('studio.trackTakes.vocals.length');
if (redone !== 2) throw new Error('Redo test failed: expected 2 clips, got ' + redone);
console.log('PASS: split preserves source timing and creates aligned clip boundaries');
console.log('PASS: undo restores the original take');
console.log('PASS: redo reapplies the split');
