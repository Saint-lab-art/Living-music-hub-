# Stage 5 — Live Acceptance Tests

Record each item as PASS, FAIL, BLOCKED, or NOT TESTED. Include date, device/browser, test account label (never password), and evidence. Use test accounts and non-sensitive sample media.

## A. Hosting and transport
- [ ] Preview URL loads over HTTPS on Android Chrome.
- [ ] `index.html`, CSS, JavaScript modules, icons and manifest load without 404 errors.
- [ ] Security response headers are present; no mixed-content warnings.
- [ ] Browser console has no uncaught startup errors or CSP violations.
- [ ] Refreshing a nested app state does not produce a host 404.

## B. Authentication and permissions
- [ ] Create a test account and complete email confirmation.
- [ ] Sign in, refresh the page, and confirm session restoration.
- [ ] Sign out and confirm private dashboard content is no longer accessible.
- [ ] Password reset works end-to-end.
- [ ] Account B cannot read or change Account A's private workspace, writing projects or assets.
- [ ] A normal user cannot grant themselves an admin/owner role.
- [ ] Admin moderation actions are rejected by backend policies for non-admin accounts.

## C. Cloud library
- [ ] Upload one small image, audio file, video and PDF to a test workspace.
- [ ] Each file appears under the correct division and project.
- [ ] Signed open/download link works for an authorised member and expires as expected.
- [ ] A second unrelated account cannot list, open, overwrite or delete the first account's private assets.
- [ ] Unsupported file types and files above the app's 100 MB UI limit are rejected.
- [ ] Interrupted upload gives a clear error and does not create a misleading completed record.
- [ ] Confirm actual Storage bucket limits, quota, retention and billing in Supabase.

## D. Five divisions and studio workflows
- [ ] Music Platform: artist profile, submission, moderation, playback and takedown.
- [ ] Music Production: record/import, edit, undo/redo, save/load and WAV export.
- [ ] Photo Studio: import, layer edit, save/load and PNG/JPG export.
- [ ] Movie Studio: import media, arrange sequential clips, preview and export on supported browser.
- [ ] Writing & Publishing: create, save, reopen and verify private ownership of a draft.
- [ ] Repeat core editing tests on a desktop browser and Android Chrome; record device model and browser version.

## E. PWA and resilience
- [ ] Install prompt / Add to Home Screen works where supported.
- [ ] Offline fallback opens after a successful first load.
- [ ] A new release updates the service-worker cache without leaving a broken mixed version.
- [ ] Clear site data and reload; app recovers and asks the user to sign in again if required.

## F. AI, money and governance — do not enable until approved
- [ ] AI Edge Function deployed with JWT verification; API key stored only in Edge Function Secrets.
- [ ] Test all five AI division actions, per-user limits, abuse controls and spend alerts.
- [ ] Owner has approved a specific AI spend budget.
- [ ] Music revenue split remains 65% creators / 35% platform.
- [ ] Books/articles remain 75% author / 25% platform.
- [ ] Creator payouts require manual owner/authorised finance-officer approval.
- [ ] No payment collection or automated payout until provider, ledger, reconciliation and refund controls pass.

## Release decision
- [ ] All critical tests pass; failures have owners and documented fixes.
- [ ] Privacy, terms, moderation and copyright processes are published.
- [ ] Backup and restore drill completed.
- [ ] Owner explicitly approves production launch.
