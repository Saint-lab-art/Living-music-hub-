// Public Supabase project configuration. The publishable key is designed for browser use.
// Never put a Supabase secret/service-role key in this file.
export const SUPABASE_URL = 'https://bflcfrjpvbrlytvjxdlu.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_ZTjAnNJwMkmPryA9lBGrzQ_QMX5o1IH';
