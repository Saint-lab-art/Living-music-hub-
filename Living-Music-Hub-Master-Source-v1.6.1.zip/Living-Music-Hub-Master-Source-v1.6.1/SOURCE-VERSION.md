# Living Music Hub — Canonical Master Source v1.6.1

Prepared: 23 November 2026

## Canonical selection

Selected source: `Living-Music-Hub-Independent-Development-v1.6.1-Stage-5-Security-Patch.zip`, saved 22 November 2026. It is the newest complete independent development package found in the project Library and contains the five-division integrated application, Stage 5 deployment preparation, and the additional Content-Security-Policy security-header patch.

The matching `Living-Music-Hub-Cloudflare-Preview-Upload-v1.6.1.zip` was also inspected. Its extracted application files match the selected independent source package. It is a hosting-oriented copy, not a separate source of truth.

## Master rule

- This v1.6.1 package is the canonical independent development master as of 23 November 2026.
- Keep all earlier ZIPs and the original project/archive unchanged as historical backups.
- Make future development changes from a copy of this master, increment the version, record changes and rerun all checks.
- Keep deployment/preview copies separate from the master source.
- GitHub is not the sole source of truth; this master is maintained independently.
- No production deployment, Supabase setting change, migration/function deployment, or credential rotation is implied by this source selection.

## Version history

- v1.1: Photo Studio layered editing and Movie Studio sequential timeline foundations.
- v1.2: AI assistant scaffolding and authenticated Edge Function source.
- v1.2.1 Stage 1: Sign-in and account-creation shortcuts.
- v1.3 Stage 2: Unified five-division dashboard and private Writing & Publishing workflow.
- v1.4 Stage 3: AI assistant interfaces for all five divisions and usage-ledger migration/function source.
- v1.5 Stage 4: Private cloud library for supported audio, image, video and document files.
- v1.6 Stage 5: Deployment preflight, static-host headers, preview-first deployment guidance and service-worker cache v6.
- v1.6.1 Stage 5 Security Patch: Adds a baseline Content-Security-Policy to `_headers` and updates the README. The policy has passed source-level checks only; preview-browser verification remains required.

## Current release limitations

This is a development master, not production certification. See `RELEASE-GATES.md`, `DEPLOYMENT-PREFLIGHT.md` and `LIVE-ACCEPTANCE-TESTS-STAGE-5.md` before any release. Live authentication, moderation, music playback, private file isolation, AI activation, real payments, creator payouts, backups/restoration, Android device QA and production hosting remain unverified or incomplete.
