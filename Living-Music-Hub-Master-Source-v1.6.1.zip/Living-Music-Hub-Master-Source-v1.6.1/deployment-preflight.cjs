const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const checks = [];
const check = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });
const exists = (name) => fs.existsSync(path.join(root, name));

for (const file of ['index.html','styles.css','app.js','config.js','studio.js','photo-video.js','studio-ai.js','hub-dashboard.js','cloud-library.js','sw.js','manifest.webmanifest','_headers']) {
  check(`Required file: ${file}`, exists(file));
}
const read = (file) => exists(file) ? fs.readFileSync(path.join(root, file), 'utf8') : '';
const html = read('index.html');
const config = read('config.js');
const allClient = ['index.html','app.js','config.js','studio.js','photo-video.js','studio-ai.js','hub-dashboard.js','cloud-library.js'].map(read).join('\n');
const url = config.match(/SUPABASE_URL\s*=\s*['"]([^'"]+)['"]/);
const key = config.match(/SUPABASE_PUBLISHABLE_KEY\s*=\s*['"]([^'"]+)['"]/);
check('Supabase project URL is HTTPS', Boolean(url && /^https:\/\//.test(url[1])));
check('Browser config uses a publishable/anon key', Boolean(key && (key[1].startsWith('sb_publishable_') || key[1].startsWith('eyJ'))));
check('No known server-side secret names in client files', !/SUPABASE_SERVICE_ROLE_KEY|SUPABASE_SECRET_KEYS|OPENAI_API_KEY|sb_secret_/i.test(allClient));
check('No obvious OpenAI secret token in client files', !/sk-[A-Za-z0-9_-]{16,}/.test(allClient));
check('No inline script blocks', !/<script(?![^>]*\bsrc=)[^>]*>/i.test(html));
const srcs = [...html.matchAll(/<script[^>]+src=["']([^"']+)["']/gi)].map(m => m[1]);
for (const src of srcs) check(`Referenced local script exists: ${src}`, /^https?:\/\//i.test(src) || exists(src.replace(/^\.\//,'')));
const sw = read('sw.js');
for (const asset of ['index.html','styles.css','app.js','config.js','studio.js','photo-video.js','studio-ai.js','hub-dashboard.js','cloud-library.js','manifest.webmanifest','icon.svg','icon-192.png','icon-512.png']) {
  check(`Service worker app-shell asset exists: ${asset}`, exists(asset) && sw.includes(`'./${asset}'`));
}
check('Service worker cache version is stage 5 or later', /CACHE\s*=\s*['"]living-music-hub-unified-platform-v[5-9]/.test(sw));

const failed = checks.filter(x => !x.ok);
for (const item of checks) console.log(`${item.ok ? 'PASS' : 'FAIL'}  ${item.name}${item.detail ? ` — ${item.detail}` : ''}`);
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed.`);
if (failed.length) process.exitCode = 1;
