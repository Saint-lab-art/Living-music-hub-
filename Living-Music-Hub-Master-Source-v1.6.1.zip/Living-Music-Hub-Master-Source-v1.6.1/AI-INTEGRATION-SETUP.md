# Living Music Hub — AI integration setup (Stage 3)

Stage 3 prepares authenticated AI workflows across all five divisions:

- **Music Platform:** artist biographies, song/album descriptions, release announcements and ethical promotion plans.
- **Music Production:** arrangement guidance, recording plans, mixing/mastering checklists and session preparation.
- **Photo & Picture Design:** image generation. Generated PNGs can be downloaded and imported into the editable canvas.
- **Movie Production:** concepts, scripts, storyboards, shot lists and editing notes. This assistant does not render a finished movie.
- **Writing & Publishing:** outlines, chapter structures, article plans, research questions and editing suggestions.

## Security and usage controls

- The browser calls the `studio-ai` Supabase Edge Function only after checking for a signed-in session.
- The Edge Function validates the caller's Supabase JWT and derives the user ID from the validated session; it does not trust a user ID supplied by the browser.
- `OPENAI_API_KEY` is read only by the Edge Function. Never place it in `config.js`, browser code, a public ZIP, or a repository.
- The function supports the current Supabase `SUPABASE_SECRET_KEYS` environment and the legacy `SUPABASE_SERVICE_ROLE_KEY` fallback. A Supabase secret/service-role key must remain server-side because it bypasses RLS.
- The `studio_ai_usage` migration enables RLS, permits users to read only their own usage rows, and revokes browser-side writes. The Edge Function records successful requests.
- Default daily limits: 3 image generations and 10 requests per text-assistant action per user. Limits can be adjusted using `STUDIO_AI_DAILY_IMAGE_LIMIT` and `STUDIO_AI_DAILY_TEXT_LIMIT` Edge Function secrets.
- Model defaults: `gpt-image-2.6-flare` for image generation and `gpt-6-luna` for text assistance. Optional overrides: `OPENAI_IMAGE_MODEL` and `OPENAI_TEXT_MODEL`.

Daily counts are a basic usage guard, not an atomic monetary budget. Simultaneous requests could race. Before a public launch, add an atomic quota reservation/RPC, spend limits and alerts in the OpenAI project, monitoring, and abuse controls.

## Deployment sequence — not yet performed

1. Review and apply `supabase/migrations/202611210001_studio_ai_usage.sql` to the intended Supabase project.
2. Add `OPENAI_API_KEY` in Supabase Dashboard → Edge Functions → Secrets. Do not send the key in ChatGPT or include it in source files.
3. Confirm the project has its default Supabase secret key available to Edge Functions. The function can also use the legacy service-role environment variable if the project still provides it.
4. Optionally set the daily limit and model override secrets.
5. Deploy `supabase/functions/studio-ai/index.ts` as `studio-ai` with JWT verification enabled (`verify_jwt = true`).
6. Test signed-in and signed-out calls, daily limits, image generation/download/import, and text-assistant outputs in each division.

**Important:** The OpenAI API is billed separately from a ChatGPT subscription. Adding an API key can incur usage charges. Do not enable live AI requests until the owner has reviewed the API pricing and set an appropriate budget.

## Current status

This is a source-code development package. The migration has not been applied, the `studio-ai` Edge Function has not been deployed, and no OpenAI key has been configured in this project during Stage 3. Therefore, the AI buttons are prepared in the interface but will not run live until the deployment sequence is completed. Existing local-first photo and movie files remain on the user's device unless separately exported or uploaded.
