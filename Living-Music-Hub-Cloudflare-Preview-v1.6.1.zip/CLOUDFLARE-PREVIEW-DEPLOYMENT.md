# Living Music Hub — Cloudflare Preview v1.6.1

This is a separate staging/preview bundle built from the designated independent master source v1.6.1. It does not overwrite the master, connect GitHub, modify Supabase, or publish the production site.

## Deploy as a Cloudflare Pages preview

1. Sign in to the Cloudflare dashboard using the project owner's account.
2. Open **Workers & Pages** and create a new Pages project using the direct-upload / upload-assets option (not a Git integration).
3. Name the preview project `living-music-hub-preview` (or another clearly marked staging name).
4. Upload the extracted contents of this package. The `index.html` file must be at the site root, not one folder deeper.
5. Use no build command; set the output directory to the uploaded project root if the dashboard asks.
6. Deploy to the generated `*.pages.dev` preview URL. Do not connect a custom production domain.
7. Open the preview URL in Android Chrome and work through `LIVE-ACCEPTANCE-TESTS-STAGE-5.md`.

## Safety gates

- Keep this deployment as preview/staging only. Do not announce it as a production launch.
- Do not add Supabase secret/service-role keys, OpenAI API keys, payment secrets, passwords, or private credentials to this bundle. `config.js` is intended to contain only the browser-safe Supabase project URL and publishable key.
- No Supabase key rotation, database migration, Edge Function deployment, or production configuration change is part of this preview preparation.
- Confirm Cloudflare response headers, HTTPS, authentication, RLS, storage isolation, uploads, playback, AI function behaviour and rollback before any production decision.
- The included `_headers` file is intended for Cloudflare Pages. Verify the actual response headers and browser console after deployment.

## Current verification

Local static checks on the master source passed: deployment preflight 37/37; Stage 5 readiness 38/38; Stage 5 deployment checks 8/8; AI integration 9/9; independent build 6/6; unified platform 7/7; creative-division AI 16/16; cloud library 13/13; studio editing checks passed; JavaScript syntax checks passed for eight client files. These are source-level checks, not live Cloudflare or device acceptance tests.
