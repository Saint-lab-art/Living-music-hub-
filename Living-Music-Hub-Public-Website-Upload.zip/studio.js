// Living Music Hub Studio — browser-based recording and live mixing tools.
// Audio stays in the browser until the user chooses to export or submit it.
const $ = (id) => document.getElementById(id);
const studio = {
  ctx: null, master: null, micGain: null, keysGain: null, drumsGain: null,
  recordDest: null, trackDests: {}, trackRecorders: {}, trackChunks: {}, trackTakes: { vocals: [], piano: [], drums: [] },
  armedTracks: { vocals: true, piano: true, drums: true }, micStream: null, micSource: null, recorder: null,
  chunks: [], lastBlob: null, lastUrl: null, oscillators: new Set(),
  sequencerTimer: null, step: 0, bpm: 110, isRecording: false,
  recordingTimer: null, recordingStartedAt: 0,
  pattern: {
    kick:  [1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],
    snare: [0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],
    hat:   [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0],
    clap:  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
  }
};
const noteNames = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
const notes = Array.from({length:25},(_,i)=>{
  const midi=48+i, name=noteNames[i%12]+(3+Math.floor(i/12));
  return {name, frequency:440*Math.pow(2,(midi-69)/12), black:[1,3,6,8,10].includes(i%12)};
});
function status(text, bad=false) { const el=$('studioStatus'); if(el){el.textContent=text;el.classList.toggle('error',bad);} }
function ensureAudio() {
  if (!studio.ctx) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) throw new Error('This browser does not support the music studio audio engine. Please use a recent version of Chrome.');
    studio.ctx = new Ctx();
    studio.master = studio.ctx.createGain();
    studio.micGain = studio.ctx.createGain();
    studio.keysGain = studio.ctx.createGain();
    studio.drumsGain = studio.ctx.createGain();
    studio.recordDest = studio.ctx.createMediaStreamDestination();
    studio.micGain.connect(studio.master);
    studio.keysGain.connect(studio.master);
    studio.drumsGain.connect(studio.master);
    // Independent pre-master track taps let each source be recorded separately.
    studio.trackDests = { vocals: studio.ctx.createMediaStreamDestination(), piano: studio.ctx.createMediaStreamDestination(), drums: studio.ctx.createMediaStreamDestination() };
    studio.micGain.connect(studio.trackDests.vocals);
    studio.keysGain.connect(studio.trackDests.piano);
    studio.drumsGain.connect(studio.trackDests.drums);
    studio.master.connect(studio.ctx.destination);
    studio.master.connect(studio.recordDest);
    studio.master.gain.value = Number($('mixMaster').value)/100;
    studio.micGain.gain.value = Number($('mixMic').value)/100;
    studio.keysGain.gain.value = Number($('mixKeys').value)/100;
    studio.drumsGain.gain.value = Number($('mixDrums').value)/100;
  }
  if (studio.ctx.state === 'suspended') studio.ctx.resume();
  return studio.ctx;
}
function tone(freq, duration=.22, type='triangle', target=studio.keysGain, peak=.22) {
  const ctx=ensureAudio(); target = target || studio.keysGain; const osc=ctx.createOscillator(), amp=ctx.createGain(), now=ctx.currentTime;
  osc.type=type; osc.frequency.setValueAtTime(freq,now);
  amp.gain.setValueAtTime(.0001,now); amp.gain.exponentialRampToValueAtTime(peak,now+.012); amp.gain.exponentialRampToValueAtTime(.0001,now+duration);
  osc.connect(amp); amp.connect(target); osc.start(now); osc.stop(now+duration+.03);
  studio.oscillators.add(osc); osc.onended=()=>studio.oscillators.delete(osc);
}
function noiseBuffer(seconds=.25) {
  const ctx=ensureAudio(), buffer=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*seconds),ctx.sampleRate), data=buffer.getChannelData(0);
  for(let i=0;i<data.length;i++) data[i]=Math.random()*2-1;
  return buffer;
}
function drum(kind) {
  const ctx=ensureAudio(), now=ctx.currentTime;
  if(kind==='kick') {
    const osc=ctx.createOscillator(), amp=ctx.createGain(); osc.type='sine'; osc.frequency.setValueAtTime(145,now); osc.frequency.exponentialRampToValueAtTime(42,now+.18);
    amp.gain.setValueAtTime(.9,now); amp.gain.exponentialRampToValueAtTime(.001,now+.34); osc.connect(amp); amp.connect(studio.drumsGain); osc.start(now); osc.stop(now+.36);
  } else {
    const src=ctx.createBufferSource(), filter=ctx.createBiquadFilter(), amp=ctx.createGain(); src.buffer=noiseBuffer(kind==='hat'?.09:.24);
    filter.type='highpass'; filter.frequency.value=kind==='hat'?6500:kind==='clap'?1200:1400;
    amp.gain.setValueAtTime(kind==='hat'?.28:.55,now); amp.gain.exponentialRampToValueAtTime(.001,now+(kind==='hat'?.075:.22));
    src.connect(filter); filter.connect(amp); amp.connect(studio.drumsGain); src.start(now); src.stop(now+(kind==='hat'?.1:.25));
    if(kind==='snare') tone(180,.08,'triangle',studio.drumsGain,.13);
    if(kind==='clap') { [0,.035,.07].forEach((d)=>{const s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=noiseBuffer(.07);g.gain.value=.23;s.connect(g);g.connect(studio.drumsGain);s.start(now+d);}); }
  }
  const pad=$(`[data-drum="${kind}"]`); if(pad){pad.classList.add('hit');setTimeout(()=>pad.classList.remove('hit'),100);}
}
function buildKeyboard() {
  const root=$('keyboardKeys'); if(!root) return;
  const whiteCount=notes.filter(n=>!n.black).length;
  const white=notes.filter(n=>!n.black).map(n=>`<button type="button" class="piano-key white-key" data-frequency="${n.frequency}" aria-label="Play ${n.name}"><span>${n.name}</span></button>`).join('');
  let whiteBefore=0;
  const black=[];
  notes.forEach(n=>{
    if(n.black){const left=(whiteBefore/whiteCount*100)-2.1;black.push(`<button type="button" class="piano-key black-key" style="left:${left}%" data-frequency="${n.frequency}" aria-label="Play ${n.name}"><span>${n.name}</span></button>`);}
    else whiteBefore++;
  });
  root.innerHTML=white+black.join('');
  root.querySelectorAll('[data-frequency]').forEach((key)=>{
    const start=(ev)=>{ev.preventDefault();key.classList.add('pressed');tone(Number(key.dataset.frequency),.45,'triangle',studio.keysGain,.2);};
    key.addEventListener('pointerdown',start);
    ['pointerup','pointercancel','pointerleave'].forEach(event=>key.addEventListener(event,()=>key.classList.remove('pressed')));
    key.addEventListener('contextmenu',(ev)=>ev.preventDefault());
  });
}
function formatTime(ms) {
  const total=Math.max(0,Math.floor(ms/1000));
  return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}
function clearRecordingTimer() {
  if(studio.recordingTimer) clearInterval(studio.recordingTimer);
  studio.recordingTimer=null;
}
function buildSequencer() {
  document.querySelectorAll('.step-row').forEach((row)=>{
    const kind=row.dataset.instrument, grid=row.querySelector('.steps');
    grid.innerHTML=Array.from({length:16},(_,i)=>`<button type="button" class="step ${studio.pattern[kind][i]?'on':''}" data-step="${i}" aria-label="${kind} step ${i+1}" aria-pressed="${!!studio.pattern[kind][i]}"></button>`).join('');
    grid.querySelectorAll('[data-step]').forEach((button)=>button.addEventListener('click',()=>{
      const i=Number(button.dataset.step);studio.pattern[kind][i]=studio.pattern[kind][i]?0:1;
      button.classList.toggle('on',!!studio.pattern[kind][i]);button.setAttribute('aria-pressed',String(!!studio.pattern[kind][i]));
    }));
  });
}
function sequencerTick() {
  const step=studio.step%16;
  for(const kind of ['kick','snare','hat','clap']) if(studio.pattern[kind][step]) drum(kind);
  document.querySelectorAll('.step').forEach((el)=>el.classList.toggle('current',Number(el.dataset.step)===step));
  studio.step=(step+1)%16;
}
function startBeat() {
  ensureAudio(); stopBeat(); studio.step=0; sequencerTick();
  const interval=(60/studio.bpm/4)*1000;
  studio.sequencerTimer=setInterval(sequencerTick,interval);
  $('beatPlay').textContent='Stop beat'; status(`Beat playing at ${studio.bpm} BPM. Start recording to capture it.`);
}
function stopBeat() {
  if(studio.sequencerTimer) clearInterval(studio.sequencerTimer);
  studio.sequencerTimer=null; $('beatPlay').textContent='Play beat';
  document.querySelectorAll('.step').forEach((el)=>el.classList.remove('current'));
}
async function toggleMic() {
  try {
    ensureAudio();
    if(studio.micStream){studio.micStream.getTracks().forEach(t=>t.stop());studio.micStream=null;studio.micSource?.disconnect();studio.micSource=null;$('micToggle').textContent='Enable microphone';status('Microphone turned off.');return;}
    if(!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone access requires HTTPS and a supported browser.');
    studio.micStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    studio.micSource=studio.ctx.createMediaStreamSource(studio.micStream);studio.micSource.connect(studio.micGain);
    $('micToggle').textContent='Turn microphone off';status('Microphone is live. Use headphones to avoid feedback while recording.');
  } catch(e){status(e.message||'Could not access the microphone.',true);}
}
function chooseRecorderType() {
  if(!window.MediaRecorder) throw new Error('Audio recording is not supported by this browser. Please use Chrome on Android or desktop.');
  const choices=['audio/webm;codecs=opus','audio/webm','audio/mp4'];
  return choices.find(t=>MediaRecorder.isTypeSupported(t))||'';
}
async function makeWav(blob) {
  const ctx = ensureAudio();
  const decoded = await ctx.decodeAudioData(await blob.arrayBuffer());
  const targetRate = 22050, channels = 1;
  const ratio = decoded.sampleRate / targetRate;
  const frames = Math.floor(decoded.length / ratio);
  const wav = new ArrayBuffer(44 + frames * 2);
  const view = new DataView(wav);
  const write = (offset, value) => { for (let i=0;i<value.length;i++) view.setUint8(offset+i,value.charCodeAt(i)); };
  write(0,'RIFF'); view.setUint32(4,36+frames*2,true); write(8,'WAVE'); write(12,'fmt ');
  view.setUint32(16,16,true); view.setUint16(20,1,true); view.setUint16(22,channels,true);
  view.setUint32(24,targetRate,true); view.setUint32(28,targetRate*2,true); view.setUint16(32,2,true); view.setUint16(34,16,true);
  write(36,'data'); view.setUint32(40,frames*2,true);
  const inputL=decoded.getChannelData(0), inputR=decoded.numberOfChannels>1?decoded.getChannelData(1):inputL;
  let offset=44;
  for(let i=0;i<frames;i++){
    const pos=i*ratio, a=Math.floor(pos), b=Math.min(a+1,decoded.length-1), frac=pos-a;
    const left=inputL[a]+(inputL[b]-inputL[a])*frac, right=inputR[a]+(inputR[b]-inputR[a])*frac;
    const sample=Math.max(-1,Math.min(1,(left+right)*.5));
    view.setInt16(offset,sample<0?sample*0x8000:sample*0x7fff,true);offset+=2;
  }
  return new Blob([wav],{type:'audio/wav'});
}
function openStudioDB() {
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open('living-music-hub-studio',1);
    request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('projects'))request.result.createObjectStore('projects');};
    request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
  });
}
async function saveStudioProject() {
  try {
    const db=await openStudioDB();
    const project={version:1,savedAt:new Date().toISOString(),bpm:studio.bpm,pattern:studio.pattern,takes:studio.trackTakes};
    await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readwrite');tx.objectStore('projects').put(project,'current');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});
    db.close();status('Studio project saved on this device.');
  } catch(e) { status(`Could not save project: ${e.message}`,true); }
}
async function loadStudioProject() {
  try {
    const db=await openStudioDB();
    const project=await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readonly');const req=tx.objectStore('projects').get('current');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});db.close();
    if(!project) { status('No saved studio project found on this device.',true); return; }
    studio.bpm=project.bpm||110;studio.pattern=project.pattern||studio.pattern;studio.trackTakes=project.takes||{vocals:[],piano:[],drums:[]};
    $('bpm').value=studio.bpm;$('bpmValue').textContent=`${studio.bpm} BPM`;buildSequencer();renderTrackTakes();status('Saved studio project loaded on this device.');
  } catch(e) { status(`Could not load project: ${e.message}`,true); }
}
function renderTrackTakes() {
  const root=$('trackTakes');if(!root)return;
  root.innerHTML='';
  const labels={vocals:'🎙️ Vocal track',piano:'🎹 Piano track',drums:'🥁 Drum track'};
  Object.entries(studio.trackTakes).forEach(([track,takes])=>{
    const section=document.createElement('section');section.className='track-lane';
    const head=document.createElement('div');head.className='track-lane-head';
    const title=document.createElement('b');title.textContent=labels[track]||track;
    const armLabel=document.createElement('label');armLabel.className='arm-label';const arm=document.createElement('input');arm.type='checkbox';arm.checked=!!studio.armedTracks[track];arm.addEventListener('change',()=>studio.armedTracks[track]=arm.checked);armLabel.append(arm,document.createTextNode(' Arm for recording'));
    head.append(title,armLabel);section.append(head);
    if(!takes.length){const empty=document.createElement('p');empty.className='muted';empty.textContent='No takes recorded yet.';section.append(empty);}
    takes.forEach((take,index)=>{
      const row=document.createElement('div');row.className='take-row';
      const name=document.createElement('span');name.textContent=`Take ${index+1} · ${(take.blob.size/1024/1024).toFixed(2)} MB`;
      const audio=document.createElement('audio');audio.controls=true;audio.preload='none';audio.src=URL.createObjectURL(take.blob);
      const download=document.createElement('a');download.className='secondary download-link';download.textContent='Download WAV';download.href=audio.src;download.download=`living-music-hub-${track}-take-${index+1}.wav`;
      const remove=document.createElement('button');remove.type='button';remove.className='secondary';remove.textContent='Delete';remove.addEventListener('click',()=>{studio.trackTakes[track].splice(index,1);renderTrackTakes();});
      row.append(name,audio,download,remove);section.append(row);
    });root.append(section);
  });
}
function startTrackRecorders() {
  studio.trackRecorders={};studio.trackChunks={};
  Object.entries(studio.trackDests).forEach(([track,destination])=>{
    if(!studio.armedTracks[track])return;
    const mimeType=chooseRecorderType();const recorder=new MediaRecorder(destination.stream,mimeType?{mimeType}:undefined);
    studio.trackChunks[track]=[];recorder.ondataavailable=e=>{if(e.data?.size)studio.trackChunks[track].push(e.data);};
    recorder.onstop=async()=>{
      try {const raw=new Blob(studio.trackChunks[track],{type:recorder.mimeType||'audio/webm'});if(raw.size){const wav=await makeWav(raw);studio.trackTakes[track].push({blob:wav,createdAt:new Date().toISOString()});renderTrackTakes();}}
      catch(e){status(`Could not prepare ${track} take: ${e.message}`,true);}
    };
    recorder.start(250);studio.trackRecorders[track]=recorder;
  });
}
function stopTrackRecorders() { Object.values(studio.trackRecorders).forEach(recorder=>{if(recorder.state!=='inactive')recorder.stop();}); }

function startRecording() {
  try {
    ensureAudio(); const mimeType=chooseRecorderType();
    studio.chunks=[];studio.lastBlob=null;$('useMix').disabled=true;$('studioPreviewWrap').classList.add('hidden');
    if(studio.lastUrl){URL.revokeObjectURL(studio.lastUrl);studio.lastUrl=null;}
    studio.recorder=new MediaRecorder(studio.recordDest.stream,mimeType?{mimeType}:undefined);
    studio.recorder.ondataavailable=(e)=>{if(e.data?.size)studio.chunks.push(e.data);};
    studio.recorder.onerror=(event)=>{
      clearRecordingTimer();studio.isRecording=false;
      $('recordStart').disabled=false;$('recordStop').disabled=true;
      status(event.error?.message||'The browser reported a recording error. Try again in Chrome.',true);
    };
    studio.recorder.onstop=async()=>{
      clearRecordingTimer();studio.isRecording=false;
      try {
        const elapsed=formatTime(Date.now()-studio.recordingStartedAt);
        const raw=new Blob(studio.chunks,{type:studio.recorder.mimeType||'audio/webm'});
        if(!raw.size) throw new Error('No audio data was captured. Check microphone permission and try again.');
        status('Preparing your studio mix as a mobile-friendly WAV file…');
        studio.lastBlob=await makeWav(raw);
        if(studio.lastUrl)URL.revokeObjectURL(studio.lastUrl);studio.lastUrl=URL.createObjectURL(studio.lastBlob);
        $('studioPreview').src=studio.lastUrl;$('studioPreviewWrap').classList.remove('hidden');
        $('recordingInfo').textContent=`WAV ready · ${elapsed} · ${(studio.lastBlob.size/1024/1024).toFixed(2)} MB · 22.05 kHz mono`;
        $('downloadMix').href=studio.lastUrl;$('downloadMix').download='living-music-hub-studio-mix.wav';
        $('useMix').disabled=false;status('Recording finished. Preview, download or attach your WAV mix to an artist submission.');
      } catch(e) { status(`Could not prepare the recording: ${e.message||'unsupported audio format'}`,true); }
      finally {$('recordStart').disabled=false;$('recordStop').disabled=true;}
    };
    studio.recorder.start(250);startTrackRecorders();studio.isRecording=true;studio.recordingStartedAt=Date.now();
    $('recordStart').disabled=true;$('recordStop').disabled=false;
    $('recordingInfo').textContent='Recording · 00:00';
    studio.recordingTimer=setInterval(()=>{$('recordingInfo').textContent=`Recording · ${formatTime(Date.now()-studio.recordingStartedAt)}`;},500);
    status('Recording your live mix. Play the keyboard, trigger drum pads or start the beat.');
  }catch(e){status(e.message||'Could not start recording.',true);}
}
function stopRecording() {
  if(studio.recorder&&studio.recorder.state!=='inactive'){
    $('recordStop').disabled=true;
    $('recordingInfo').textContent='Finishing recording…';
    studio.recorder.stop();stopTrackRecorders();studio.isRecording=false;
  }
}
function useMixForUpload() {
  if(!studio.lastBlob)return;
  const ext='wav';
  const file=new File([studio.lastBlob],`living-music-hub-studio-mix.${ext}`,{type:'audio/wav'});
  const input=$('uploadForm')?.elements.audio;
  if(!input)return;
  const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;
  document.querySelector('#upload').scrollIntoView({behavior:'smooth'});
  const title=$('uploadForm').elements.title;if(title&&!title.value)title.value='My Studio Recording';
  const note=$('uploadStatus');if(note)note.textContent='Studio mix attached. Add your song details and rights confirmation, then submit for review.';
}
function bindMixers() {
  [['mixMaster','master'],['mixMic','micGain'],['mixKeys','keysGain'],['mixDrums','drumsGain']].forEach(([id,key])=>$(id).addEventListener('input',e=>{
    if(studio[key])studio[key].gain.setTargetAtTime(Number(e.target.value)/100,studio.ctx.currentTime,.015);
    $(`${id}Value`).textContent=`${e.target.value}%`;
  }));
}
function init() {
  buildKeyboard();buildSequencer();bindMixers();
  document.querySelectorAll('[data-drum]').forEach(p=>p.addEventListener('pointerdown',e=>{e.preventDefault();drum(p.dataset.drum);}));
  $('micToggle').addEventListener('click',toggleMic);
  $('beatPlay').addEventListener('click',()=>studio.sequencerTimer?stopBeat():startBeat());
  $('bpm').addEventListener('input',e=>{studio.bpm=Number(e.target.value);$('bpmValue').textContent=`${studio.bpm} BPM`;if(studio.sequencerTimer)startBeat();});
  $('recordStart').addEventListener('click',startRecording);$('recordStop').addEventListener('click',stopRecording);$('useMix').addEventListener('click',useMixForUpload);
  $('saveStudioProject')?.addEventListener('click',saveStudioProject);$('loadStudioProject')?.addEventListener('click',loadStudioProject);renderTrackTakes();
  $('downloadMix').addEventListener('click',()=>{if(!studio.lastBlob)status('Make a recording first.',true);});
  window.addEventListener('beforeunload',()=>{stopBeat();studio.micStream?.getTracks().forEach(t=>t.stop());});
}
init();
