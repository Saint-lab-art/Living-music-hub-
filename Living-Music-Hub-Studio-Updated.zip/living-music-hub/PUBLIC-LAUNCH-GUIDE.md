# Living Music Hub — public launch guide

## Backend status

An existing Supabase project in the **Living Music Hub** organisation was found and is active. The project is in the London (`eu-west-2`) region. Its database already contains the main platform tables and Row Level Security policies. The mobile website in this package is now connected to that project using its public publishable key.

The following backend changes have been applied:

- A profile is automatically created when a user signs up.
- Song submissions must carry an affirmative rights declaration and remain `pending` until an administrator approves them.
- Public catalogue indexes have been added.
- The `music-audio` bucket has been made private. Artists can read their own pending audio; public visitors can read audio only after the corresponding song is published.
- Artist artwork remains in its separate public image bucket.

## Studio update

The mobile website now includes a browser-based music studio with microphone capture, playable piano keys, kick/snare/hi-hat/clap pads, a 16-step sequencer, BPM control, live channel-level mixing and recording. The recorded live mix is converted to a WAV file for preview, download or artist upload. This is an initial live-mix studio, not yet a full multitrack DAW with independent track editing, effect chains or automation.

## What you must do next

### 1. Create the owner account

1. Deploy the site to a temporary HTTPS preview (or run it at `http://localhost:8000` for initial testing).
2. Open **Account** and create an account using an email address you control.
3. Confirm the email if Supabase asks you to.
4. Sign in and save your artist profile.

### 2. Make the owner an administrator

Do not grant administrator access to an unverified account. Once you have created and confirmed your account, find its UUID in Supabase → Authentication → Users. Then run this in the SQL Editor, replacing the placeholder with the exact UUID:

```sql
insert into public.admin_users (user_id)
values ('PASTE-YOUR-VERIFIED-AUTH-USER-UUID-HERE')
on conflict (user_id) do nothing;
```

This is intentionally a manual owner-only step; the first person to sign up is not automatically made an administrator.

### 3. Configure authentication URLs

In Supabase → Authentication → URL Configuration:
- Set the Site URL to the final HTTPS website URL.
- Add the exact website URL and any required password-reset/callback paths to the allowed redirect URLs.
- Do not use a temporary preview URL as the final Site URL.

### 4. Deploy the website

The folder can be deployed as a static site to Netlify, Vercel or Cloudflare Pages. Upload the contents of this folder (not the ZIP file itself) and connect a domain you control. HTTPS must be enabled. No hosting provider or domain has been connected yet.

### 5. Test before public promotion

- Listener: browse published music, search, play, favourite, sign out.
- Artist: create profile, upload an original track, confirm that it appears as pending in My Submissions.
- Privacy: verify that a different signed-out visitor cannot play the pending audio file.
- Admin: sign in as the verified administrator, publish the pending track, then confirm it appears in public Discover and streams.
- Rejected track: verify that a rejected track does not appear publicly.
- Studio: test microphone permission, keyboard, drum pads, sequencer, mixer and WAV recording/export on Android Chrome with headphones.
- Mobile: test Android Chrome, installation prompt, audio controls and responsive layout.

## Security note

A Supabase secret/service-role key was previously pasted into a ChatGPT conversation. Treat that secret as exposed and rotate/revoke it in Supabase Project Settings → API Keys. The website does not use the secret key; it uses only the public publishable key. Never send passwords, one-time codes or secret keys in chat.

## Legal and operational readiness

Before opening public submissions, add and approve:
- Privacy policy and terms of use.
- Artist distribution/upload agreement and explicit rights warranty.
- Copyright complaint and takedown contact/process.
- Community rules, prohibited-content rules and moderation escalation.
- Backup, monitoring and abuse-reporting procedures.

Seek appropriate Zambian legal advice on copyright, privacy/data protection and business obligations. This platform must not distribute commercial recordings without the necessary rights.


## Owner administrator access

1. Create the owner account using **innocenttheodorechirwa86@gmail.com** through the website sign-up form.
2. Complete the email verification link.
3. In Supabase Dashboard → SQL Editor, run `supabase/grant_owner_admin.sql`. It refuses to grant access unless the exact owner email has a verified Auth account.
4. Sign out and back in on the website. The Music review desk should appear.
5. Test with one pending song: publish one test submission and reject a second.

Do not add an administrator row for an unverified account. The `admin_users` table is intentionally not writable from the public website; use the Supabase SQL Editor for this owner-only operation.

## Android recording validation

Follow `ANDROID-RECORDING-TEST.md` on the actual Android phone over HTTPS. The physical microphone, recording codec, WAV export, and playback cannot be certified from a code review alone.
