# Living Music Hub — Android real-device recording test

**Target device:** Android phone, Chrome browser, HTTPS website.
**Test account:** use a separate artist test account; do not use the owner account for upload tests.
**Important:** browser microphone permission and actual sound capture can only be verified on the physical phone. A desktop or code review cannot certify the phone's microphone, speaker, codec support, or thermal/performance behaviour.

## Before testing
1. Publish the site to an HTTPS address. Microphone capture is normally blocked on insecure non-local origins.
2. Open the site in current Google Chrome on Android.
3. Connect wired/Bluetooth headphones if available to prevent speaker feedback.
4. In Android Settings → Apps → Chrome → Permissions, allow Microphone; also allow it when the website asks.
5. Keep the phone charged and close other audio/recording apps.

## Test sequence
- [ ] Open Music Studio and tap **Enable microphone**. Android/Chrome permission prompt appears if permission has not already been granted.
- [ ] Allow permission; the page reports that the microphone is live.
- [ ] Speak normally; verify the microphone is audible in headphones/monitor path if monitoring is enabled by the browser/device.
- [ ] Tap several white and black piano keys across both octaves; each produces the expected tone.
- [ ] Tap Kick, Snare, Hi-hat and Clap pads; each produces a distinct sound.
- [ ] Start the beat; change BPM; verify the tempo changes. Toggle several 16-step cells and confirm the pattern changes.
- [ ] Start recording; confirm the elapsed-time display advances; speak/sing into the microphone, play white/black keys and trigger drums for 10–20 seconds.
- [ ] Stop recording and wait for WAV conversion to finish.
- [ ] Play the preview. Confirm voice and instruments are present and not badly distorted.
- [ ] Download the WAV and play it in a separate Android audio player. Confirm it is not silent or truncated.
- [ ] Attach the recording to a test artist upload, submit with rights declaration, and confirm it appears as **pending**.
- [ ] Sign out and confirm the pending track is not visible to public listeners.
- [ ] Repeat once with microphone permission denied; confirm a clear permission error is shown and the rest of the studio still works.
- [ ] Turn microphone off and confirm the browser microphone indicator disappears.

## Results to record
- Phone make/model: ______________________________
- Android version: ________________________________
- Chrome version: __________________________________
- Site HTTPS URL: __________________________________
- Date/time: ______________________________________
- Microphone permission: Pass / Fail
- Voice in exported WAV: Pass / Fail
- Keyboard and drums in exported WAV: Pass / Fail
- WAV preview and download: Pass / Fail
- Artist upload pending and private: Pass / Fail
- Notes / error message: ___________________________

## Known studio scope
This release records one mixed WAV file (22.05 kHz, mono). It is not yet a multitrack editor with separate editable tracks. Use headphones. Long recordings can create large files; keep early tests short and under the platform's 50 MB upload limit.
