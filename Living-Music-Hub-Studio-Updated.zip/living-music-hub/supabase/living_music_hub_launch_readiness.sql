-- Applied to the existing Living Music Hub Supabase project on 14 November 2026.
-- Adds rights confirmation, a profile-on-signup trigger and public-catalogue indexes.
alter table public.songs
  add column if not exists rights_confirmed boolean not null default false,
  add column if not exists rights_confirmed_at timestamptz;
create or replace function public.handle_new_lmh_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'full_name', ''), split_part(coalesce(new.email, ''), '@', 1)))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_lmh_auth_user_created on auth.users;
create trigger on_lmh_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_lmh_user();
drop policy if exists "Artists submit songs for review" on public.songs;
create policy "Artists submit songs for review" on public.songs for insert to authenticated
with check (status = 'pending' and rights_confirmed = true and exists (
  select 1 from public.artist_profiles ap where ap.id = songs.artist_id and ap.user_id = (select auth.uid())
));
create index if not exists songs_published_created_idx on public.songs (created_at desc) where status = 'published';
create index if not exists songs_genre_published_idx on public.songs (genre, created_at desc) where status = 'published';
create index if not exists songs_artist_id_idx on public.songs (artist_id);
update storage.buckets set public = false where id = 'music-audio';
drop policy if exists "Public can read published media buckets" on storage.objects;
create policy "Public can read artwork and published music" on storage.objects for select to anon, authenticated
using (bucket_id = 'artist-artwork' or (bucket_id = 'music-audio' and (
  (auth.uid() is not null and (storage.foldername(name))[1] = auth.uid()::text)
  or exists (select 1 from public.songs s where s.audio_path = storage.objects.name and s.status = 'published')
)));

-- Keep the SECURITY DEFINER signup trigger private from direct RPC calls.
revoke all on function public.handle_new_lmh_user() from public, anon, authenticated;
