-- Living Music Hub: grant owner administrator access after email verification.
-- Run once in Supabase SQL Editor AFTER creating and verifying the owner account.
-- This script grants access only to the exact owner email configured for this project.

do $$
declare
  owner_user_id uuid;
begin
  select id into owner_user_id
  from auth.users
  where lower(email) = lower('innocenttheodorechirwa86@gmail.com')
    and email_confirmed_at is not null;

  if owner_user_id is null then
    raise exception 'No verified Auth account found for innocenttheodorechirwa86@gmail.com. Create the account and verify its email first; no administrator access was granted.';
  end if;

  insert into public.admin_users (user_id)
  values (owner_user_id)
  on conflict (user_id) do nothing;
end
$$;

-- Verification: this should return exactly one row after successful execution.
select au.user_id, u.email, au.created_at
from public.admin_users au
join auth.users u on u.id = au.user_id
where lower(u.email) = lower('innocenttheodorechirwa86@gmail.com');
