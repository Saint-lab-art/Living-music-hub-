const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const js = fs.readFileSync('photo-video.js', 'utf8');
const sw = fs.readFileSync('sw.js', 'utf8');
const requiredIds = [
  'designCanvas','designImage','designSize','photoAddHeading','photoAddRect','photoLayerList',
  'photoUndo','photoRedo','photoSave','photoLoad','photoExportPng','photoExportJpg',
  'movieFiles','movieAudioFiles','moviePreview','movieRenderCanvas','movieClipList','movieTimeline',
  'movieApplyTrim','moviePlaySequence','movieExport','movieSave','movieLoad','movieNotes'
];
for (const id of requiredIds) if (!html.includes(`id="${id}"`)) throw new Error(`Missing HTML control: ${id}`);
if (!html.includes('src="photo-video.js"')) throw new Error('Photo/video module not loaded');
if (!sw.includes("'./photo-video.js'")) throw new Error('Photo/video module missing from app shell cache');
for (const token of ['photoAddHeading','photoDuplicateLayer','photoUndo','toBlob','lmh-photo-project','movieTimeline','movieApplyTrim','MediaRecorder','captureStream','lmh-movie-project']) {
  if (!js.includes(token)) throw new Error(`Missing expected studio capability: ${token}`);
}
if (!sw.includes('unified-platform-v7')) throw new Error('Service-worker cache was not versioned for the unified platform release');
if (!sw.includes('./hub-dashboard.js')) throw new Error('Unified dashboard module missing from offline app shell');
if (!sw.includes("'./studio-ai.js'")) throw new Error('AI module missing from app shell cache');
console.log('PASS: photo editor includes layers, shapes, drag positioning, undo/redo and project import/export');
console.log('PASS: photo editor supports PNG/JPG output and image fitting');
console.log('PASS: movie editor includes video/audio media bin, sequence timeline and trim controls');
console.log('PASS: movie editor includes sequence preview, project packages and browser video export');
console.log('PASS: service worker includes the updated creative-studio cache version');

for (const token of ['class=\"auth-shortcut auth-shortcut-secondary\" data-scroll=\"account\"','class=\"auth-shortcut auth-shortcut-primary\" data-scroll=\"account\"','id=\"signInForm\"','id=\"signUpForm\"']) {
  if (!html.includes(token)) throw new Error(`Missing Stage 1 authentication access control: ${token}`);
}
console.log('PASS: Stage 1 header sign-in/create-account shortcuts link to the existing authentication forms');
