# Living Music Hub — Consolidated Preview Candidate v1.8

**Status:** Current consolidated working candidate; not a production release.  
**Prepared:** 24 November 2026

This package combines the updated application files from the uploaded v1.8 archive with the operational, backend and verification materials omitted from that archive but present in v1.7.

## Five divisions
1. Music Platform
2. Music Production Studio
3. Photo & Picture Designing Studio
4. Movie & Video Production Studio
5. Writing & Publishing

## Included
- Updated integrated browser application and Supabase browser configuration.
- Music, music production, photo, movie/video, and writing/publishing interfaces.
- Five-division dashboard, AI client interfaces and private cloud-library client module.
- Retained Supabase Edge Function and migration source from v1.7.
- PWA assets, deployment headers, preflight checks, test scripts and release documentation.

## Local checks
Requires Node.js. Run:

```bash
node deployment-preflight.cjs
for f in tests-*.cjs; do node "$f" || exit 1; done
for f in *.js; do node --check "$f" || exit 1; done
```

## Release boundaries
This is a preview candidate, not production certification. Live authentication, RLS, private file isolation, AI activation, payments, payouts, backups/restoration, Android device QA and live hosting remain unverified. Keep preview separate from production. Do not place Supabase secret/service-role keys or OpenAI keys in browser files.
