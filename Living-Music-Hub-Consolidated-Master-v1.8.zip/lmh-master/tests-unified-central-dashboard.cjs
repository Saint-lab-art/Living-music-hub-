const fs = require('fs');
const path = require('path');
const root = __dirname;
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'hub-dashboard.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
const checks = [
  ['central dashboard overview region exists', html.includes('id="hubOverviewGrid"')],
  ['dashboard refresh control exists', html.includes('id="hubRefreshBtn"')],
  ['all five division project counts are queried', Object.keys({music:1,music_production:1,photo_design:1,movie_production:1,publishing:1}).every(k => js.includes(k)) && js.includes("count:'exact',head:true")],
  ['overview is scoped to signed-in workspace', js.includes("eq('workspace_id',workspaceId)")],
  ['project cards link to their relevant division', js.includes('divisionTargets[p.division]')],
  ['dashboard refresh reloads shared data', js.includes("hubRefreshBtn") && js.includes('loadOverview(),loadProjects(),loadPublishing()')],
  ['responsive dashboard metric styling exists', css.includes('.hub-overview-grid') && css.includes('@media(max-width:700px)')],
  ['no privileged key is used by dashboard client', js.includes('SUPABASE_PUBLISHABLE_KEY') && !/service[_-]?role|sb_secret_/i.test(js)],
];
let failed=false; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}: ${name}`);if(!ok)failed=true;} if(failed)process.exit(1);
