# Living Music Hub — Consolidated Preview Candidate v1.8

Prepared: 24 November 2026

This consolidated package retains the Stage 5 deployment-preparation and security baseline.

## Source selection

This candidate uses the updated application modules and interface from the uploaded v1.8 archive, while retaining the deployment documentation, preflight tooling, tests, Supabase Edge Function, migration, and reference material present in the uploaded v1.7 archive but omitted from v1.8.

## Master rule

- Use this consolidated v1.8 candidate as the current working preview source after local checks.
- Preserve both uploaded archives unchanged as historical inputs.
- Keep preview separate from production. Do not publish to a production hostname or change Supabase settings without explicit owner approval.
- The included Supabase migration and Edge Function are source artifacts only; they are not deployed by this package.

## Changes from v1.7 application files

- Updated application modules and interface are taken from v1.8.
- Service-worker cache name advances from v6 to v7 to invalidate older cached app shells.
- v1.7 operational documentation, tests, deployment preflight, Supabase function/migration and reference source are retained.

## Release boundary

Local syntax and scripted source checks do not verify live Cloudflare hosting, Supabase authentication/RLS, storage isolation, actual media recording/export on Android, AI execution, payments, creator payouts, or backup restoration. This package is a preview candidate, not production certification.
