const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const checks = [
  ['Deployment preflight script exists', fs.existsSync(path.join(root, 'deployment-preflight.cjs'))],
  ['Deployment guide documents preview-first release', /preview\/staging.*site first/i.test(read('DEPLOYMENT-PREFLIGHT.md'))],
  ['Deployment guide warns against browser secrets', /never put.*OPENAI_API_KEY/is.test(read('DEPLOYMENT-PREFLIGHT.md'))],
  ['Security headers include MIME sniffing protection', /X-Content-Type-Options:\s*nosniff/i.test(read('_headers'))],
  ['Security headers include frame protection', /X-Frame-Options:\s*DENY/i.test(read('_headers'))],
  ['Service worker cache advanced to v7', /living-music-hub-unified-platform-v7/.test(read('sw.js'))],
  ['Guide explicitly says package is not deployed', /not deployed/i.test(read('DEPLOYMENT-PREFLIGHT.md'))],
  ['Rollback guidance distinguishes backend data', /does not roll back Supabase database migrations/i.test(read('DEPLOYMENT-PREFLIGHT.md'))],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
console.log(`${checks.length - failed}/${checks.length} Stage 5 checks passed.`);
if (failed) process.exitCode = 1;
