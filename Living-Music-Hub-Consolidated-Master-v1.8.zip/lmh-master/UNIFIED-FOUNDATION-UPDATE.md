# Living Music Hub — Unified Foundation Update

Development update based on master source v1.6.1.

## Central dashboard improvements
- Workspace-scoped overview metrics for all five approved divisions.
- Exact row counts returned by PostgREST count queries, rather than counting only the recent-project list.
- Recent project shortcuts to the matching division workspace.
- Manual refresh for project, publishing and overview data.
- Responsive layout for mobile and desktop.

## Architecture preserved
One authenticated account → one personal workspace → five division work areas → shared projects and private assets. Existing Supabase Row Level Security remains the authority for access. Finance data stays behind the finance API and is not queried directly from the browser.

## Verification required
Source tests do not prove live authentication, data isolation, Android behavior or production readiness. Those remain release gates.
