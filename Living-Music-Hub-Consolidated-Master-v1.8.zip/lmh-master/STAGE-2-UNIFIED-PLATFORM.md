# Stage 2 — Unified foundation and central dashboard

## Included in this development update
- Retains one shared Supabase identity and personal workspace for all five divisions.
- Adds a central overview showing exact project counts per division, scoped to the signed-in user's workspace.
- Adds a total project count, recent project list, division shortcuts and a manual refresh control.
- Retains the existing workspace, publishing and private cloud-library workflows.
- Uses the existing database tables and Row Level Security; no schema changes or privileged client keys are introduced.

## Existing backend foundation confirmed
- `creative_workspaces`, `workspace_members`, `creative_projects`, `creative_assets`, `publishing_works`, `education_resources`, `studio_service_requests` and `ai_jobs` are present.
- The finance schema contains private revenue policies, transactions, earnings, payout requests, professional payables, ledger entries, accounts, finance roles and audit events.
- All inspected tables have RLS enabled. The private finance schema denies direct client access; finance information must continue through the authenticated server-side finance API.

## Not yet complete
- Live Android sign-in and workspace creation tests.
- Two-account/two-workspace isolation tests.
- Live counts and project creation tests against a deployed preview.
- Central finance summary integration after the finance API and owner-role workflow pass end-to-end security tests.
- Unified role/permission display and administrator controls.
- Payment processing, actual creator payouts and reconciliation.

## Safety boundary
This update changes only the local development source package. It does not modify GitHub, deploy to Cloudflare, change Supabase schema, alter account settings, create accounts or rotate keys.
