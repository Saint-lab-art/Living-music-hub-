// Living Music Hub Studio — browser-based recording and live mixing tools.
// Audio stays in the browser until the user chooses to export or submit it.
const $ = (id) => document.getElementById(id);
const studio = {
  ctx: null, master: null, micGain: null, keysGain: null, drumsGain: null,
  recordDest: null, trackDests: {}, trackRecorders: {}, trackChunks: {}, trackTakes: { vocals: [], piano: [], drums: [] },
  armedTracks: { vocals: true, piano: true, drums: true }, micStream: null, micSource: null, recorder: null,
  chunks: [], lastBlob: null, lastUrl: null, oscillators: new Set(),
  sequencerTimer: null, step: 0, bpm: 110, isRecording: false,
  recordingTimer: null, recordingStartedAt: 0, pianoVoices: new Map(),
  trackMix: { vocals: 1, piano: 1, drums: 1 }, trackMuted: { vocals: false, piano: false, drums: false }, trackSolo: { vocals: false, piano: false, drums: false }, trackPan: { vocals: 0, piano: 0, drums: 0 }, arrangementSources: [], arrangementPlaying: false,
  undoStack: [], redoStack: [], historyLimit: 40,
  pattern: {
    kick:  [1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],
    snare: [0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],
    hat:   [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0],
    clap:  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
  }
};
const decodedTakeCache = new WeakMap();
const noteNames = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
const notes = Array.from({length:25},(_,i)=>{
  const midi=48+i, name=noteNames[i%12]+(3+Math.floor(i/12));
  return {name, frequency:440*Math.pow(2,(midi-69)/12), black:[1,3,6,8,10].includes(i%12)};
});
function status(text, bad=false) { const el=$('studioStatus'); if(el){el.textContent=text;el.classList.toggle('error',bad);} }
function ensureAudio() {
  if (!studio.ctx) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) throw new Error('This browser does not support the music studio audio engine. Please use a recent version of Chrome.');
    studio.ctx = new Ctx();
    studio.master = studio.ctx.createGain();
    studio.micGain = studio.ctx.createGain();
    studio.keysGain = studio.ctx.createGain();
    studio.drumsGain = studio.ctx.createGain();
    studio.recordDest = studio.ctx.createMediaStreamDestination();
    studio.micGain.connect(studio.master);
    studio.keysGain.connect(studio.master);
    studio.drumsGain.connect(studio.master);
    // Independent pre-master track taps let each source be recorded separately.
    studio.trackDests = { vocals: studio.ctx.createMediaStreamDestination(), piano: studio.ctx.createMediaStreamDestination(), drums: studio.ctx.createMediaStreamDestination() };
    studio.micGain.connect(studio.trackDests.vocals);
    studio.keysGain.connect(studio.trackDests.piano);
    studio.drumsGain.connect(studio.trackDests.drums);
    studio.master.connect(studio.ctx.destination);
    studio.master.connect(studio.recordDest);
    studio.master.gain.value = Number($('mixMaster').value)/100;
    studio.micGain.gain.value = Number($('mixMic').value)/100;
    studio.keysGain.gain.value = Number($('mixKeys').value)/100;
    studio.drumsGain.gain.value = Number($('mixDrums').value)/100;
  }
  if (studio.ctx.state === 'suspended') studio.ctx.resume();
  return studio.ctx;
}
function tone(freq, duration=.22, type='triangle', target=studio.keysGain, peak=.22) {
  const ctx=ensureAudio(); target = target || studio.keysGain; const osc=ctx.createOscillator(), amp=ctx.createGain(), now=ctx.currentTime;
  osc.type=type; osc.frequency.setValueAtTime(freq,now);
  amp.gain.setValueAtTime(.0001,now); amp.gain.exponentialRampToValueAtTime(peak,now+.012); amp.gain.exponentialRampToValueAtTime(.0001,now+duration);
  osc.connect(amp); amp.connect(target); osc.start(now); osc.stop(now+duration+.03);
  studio.oscillators.add(osc); osc.onended=()=>studio.oscillators.delete(osc);
}
function noiseBuffer(seconds=.25) {
  const ctx=ensureAudio(), buffer=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*seconds),ctx.sampleRate), data=buffer.getChannelData(0);
  for(let i=0;i<data.length;i++) data[i]=Math.random()*2-1;
  return buffer;
}
function drum(kind) {
  const ctx=ensureAudio(), now=ctx.currentTime;
  if(kind==='kick') {
    const osc=ctx.createOscillator(), amp=ctx.createGain(); osc.type='sine'; osc.frequency.setValueAtTime(145,now); osc.frequency.exponentialRampToValueAtTime(42,now+.18);
    amp.gain.setValueAtTime(.9,now); amp.gain.exponentialRampToValueAtTime(.001,now+.34); osc.connect(amp); amp.connect(studio.drumsGain); osc.start(now); osc.stop(now+.36);
  } else {
    const src=ctx.createBufferSource(), filter=ctx.createBiquadFilter(), amp=ctx.createGain(); src.buffer=noiseBuffer(kind==='hat'?.09:.24);
    filter.type='highpass'; filter.frequency.value=kind==='hat'?6500:kind==='clap'?1200:1400;
    amp.gain.setValueAtTime(kind==='hat'?.28:.55,now); amp.gain.exponentialRampToValueAtTime(.001,now+(kind==='hat'?.075:.22));
    src.connect(filter); filter.connect(amp); amp.connect(studio.drumsGain); src.start(now); src.stop(now+(kind==='hat'?.1:.25));
    if(kind==='snare') tone(180,.08,'triangle',studio.drumsGain,.13);
    if(kind==='clap') { [0,.035,.07].forEach((d)=>{const s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=noiseBuffer(.07);g.gain.value=.23;s.connect(g);g.connect(studio.drumsGain);s.start(now+d);}); }
  }
  const pad=$(`[data-drum="${kind}"]`); if(pad){pad.classList.add('hit');setTimeout(()=>pad.classList.remove('hit'),100);}
}
function buildKeyboard() {
  const root=$('keyboardKeys'); if(!root) return;
  const whiteCount=notes.filter(n=>!n.black).length;
  const white=notes.filter(n=>!n.black).map(n=>`<button type="button" class="piano-key white-key" data-frequency="${n.frequency}" aria-label="Play ${n.name}"><span>${n.name}</span></button>`).join('');
  let whiteBefore=0;
  const black=[];
  notes.forEach(n=>{
    if(n.black){const left=(whiteBefore/whiteCount*100)-2.1;black.push(`<button type="button" class="piano-key black-key" style="left:${left}%" data-frequency="${n.frequency}" aria-label="Play ${n.name}"><span>${n.name}</span></button>`);}
    else whiteBefore++;
  });
  root.innerHTML=white+black.join('');
  root.querySelectorAll('[data-frequency]').forEach((key)=>{
    key.addEventListener('pointerdown',(ev)=>{
      ev.preventDefault();
      try {
        ensureAudio();
        if(studio.pianoVoices.has(key)) return;
        const now=studio.ctx.currentTime;
        const osc=studio.ctx.createOscillator();
        const voice=studio.ctx.createGain();
        osc.type='triangle';
        osc.frequency.setValueAtTime(Number(key.dataset.frequency),now);
        voice.gain.setValueAtTime(.0001,now);
        voice.gain.exponentialRampToValueAtTime(.19,now+.018);
        voice.gain.setTargetAtTime(.105,now+.08,.16);
        osc.connect(voice);voice.connect(studio.keysGain);osc.start(now);
        studio.pianoVoices.set(key,{osc,voice});
        key.classList.add('pressed');
        if(key.setPointerCapture) key.setPointerCapture(ev.pointerId);
      } catch(error) { status(error.message||'Could not play piano key.',true); }
    });
    const release=()=>{
      const active=studio.pianoVoices.get(key);
      if(active){
        const now=studio.ctx.currentTime;
        active.voice.gain.cancelScheduledValues(now);
        active.voice.gain.setTargetAtTime(.0001,now,.045);
        active.osc.stop(now+.22);
        studio.pianoVoices.delete(key);
      }
      key.classList.remove('pressed');
    };
    ['pointerup','pointercancel','lostpointercapture'].forEach(event=>key.addEventListener(event,release));
    key.addEventListener('contextmenu',(ev)=>ev.preventDefault());
  });
}
function formatTime(ms) {
  const total=Math.max(0,Math.floor(ms/1000));
  return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}
function clearRecordingTimer() {
  if(studio.recordingTimer) clearInterval(studio.recordingTimer);
  studio.recordingTimer=null;
}
function buildSequencer() {
  document.querySelectorAll('.step-row').forEach((row)=>{
    const kind=row.dataset.instrument, grid=row.querySelector('.steps');
    grid.innerHTML=Array.from({length:16},(_,i)=>`<button type="button" class="step ${studio.pattern[kind][i]?'on':''}" data-step="${i}" aria-label="${kind} step ${i+1}" aria-pressed="${!!studio.pattern[kind][i]}"></button>`).join('');
    grid.querySelectorAll('[data-step]').forEach((button)=>button.addEventListener('click',()=>{
      const i=Number(button.dataset.step);studio.pattern[kind][i]=studio.pattern[kind][i]?0:1;
      button.classList.toggle('on',!!studio.pattern[kind][i]);button.setAttribute('aria-pressed',String(!!studio.pattern[kind][i]));
    }));
  });
}
function sequencerTick() {
  const step=studio.step%16;
  for(const kind of ['kick','snare','hat','clap']) if(studio.pattern[kind][step]) drum(kind);
  document.querySelectorAll('.step').forEach((el)=>el.classList.toggle('current',Number(el.dataset.step)===step));
  studio.step=(step+1)%16;
}
function startBeat() {
  ensureAudio(); stopBeat(); studio.step=0; sequencerTick();
  const interval=(60/studio.bpm/4)*1000;
  studio.sequencerTimer=setInterval(sequencerTick,interval);
  $('beatPlay').textContent='Stop beat'; status(`Beat playing at ${studio.bpm} BPM. Start recording to capture it.`);
}
function stopBeat() {
  if(studio.sequencerTimer) clearInterval(studio.sequencerTimer);
  studio.sequencerTimer=null; $('beatPlay').textContent='Play beat';
  document.querySelectorAll('.step').forEach((el)=>el.classList.remove('current'));
}
async function toggleMic() {
  try {
    ensureAudio();
    if(studio.micStream){studio.micStream.getTracks().forEach(t=>t.stop());studio.micStream=null;studio.micSource?.disconnect();studio.micSource=null;$('micToggle').textContent='Enable microphone';status('Microphone turned off.');return;}
    if(!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone access requires HTTPS and a supported browser.');
    studio.micStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false,channelCount:1}});
    studio.micSource=studio.ctx.createMediaStreamSource(studio.micStream);studio.micSource.connect(studio.micGain);
    $('micToggle').textContent='Turn microphone off';status('Microphone is live. Use headphones to avoid feedback while recording.');
  } catch(e){status(e.message||'Could not access the microphone.',true);}
}
function chooseRecorderType() {
  if(!window.MediaRecorder) throw new Error('Audio recording is not supported by this browser. Please use Chrome on Android or desktop.');
  const choices=['audio/webm;codecs=opus','audio/webm','audio/mp4'];
  return choices.find(t=>MediaRecorder.isTypeSupported(t))||'';
}
async function makeWav(blob) {
  const ctx = ensureAudio();
  const decoded = await ctx.decodeAudioData(await blob.arrayBuffer());
  const targetRate = 22050, channels = 1;
  const ratio = decoded.sampleRate / targetRate;
  const frames = Math.floor(decoded.length / ratio);
  const wav = new ArrayBuffer(44 + frames * 2);
  const view = new DataView(wav);
  const write = (offset, value) => { for (let i=0;i<value.length;i++) view.setUint8(offset+i,value.charCodeAt(i)); };
  write(0,'RIFF'); view.setUint32(4,36+frames*2,true); write(8,'WAVE'); write(12,'fmt ');
  view.setUint32(16,16,true); view.setUint16(20,1,true); view.setUint16(22,channels,true);
  view.setUint32(24,targetRate,true); view.setUint32(28,targetRate*2,true); view.setUint16(32,2,true); view.setUint16(34,16,true);
  write(36,'data'); view.setUint32(40,frames*2,true);
  const inputL=decoded.getChannelData(0), inputR=decoded.numberOfChannels>1?decoded.getChannelData(1):inputL;
  let offset=44;
  for(let i=0;i<frames;i++){
    const pos=i*ratio, a=Math.floor(pos), b=Math.min(a+1,decoded.length-1), frac=pos-a;
    const left=inputL[a]+(inputL[b]-inputL[a])*frac, right=inputR[a]+(inputR[b]-inputR[a])*frac;
    const sample=Math.max(-1,Math.min(1,(left+right)*.5));
    view.setInt16(offset,sample<0?sample*0x8000:sample*0x7fff,true);offset+=2;
  }
  return new Blob([wav],{type:'audio/wav'});
}
function openStudioDB() {
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open('living-music-hub-studio',1);
    request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('projects'))request.result.createObjectStore('projects');};
    request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
  });
}
async function saveStudioProject() {
  try {
    const db=await openStudioDB();
    const project={version:3,savedAt:new Date().toISOString(),bpm:studio.bpm,pattern:studio.pattern,takes:studio.trackTakes,trackMix:studio.trackMix,trackMuted:studio.trackMuted,trackSolo:studio.trackSolo,trackPan:studio.trackPan};
    await new Promise((resolve,reject)=>{
      const tx=db.transaction('projects','readwrite'),store=tx.objectStore('projects'),previous=store.get('current');
      previous.onsuccess=()=>{if(previous.result)store.put(previous.result,'previous');store.put(project,'current');};
      tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Project save was interrupted.'));
    });
    db.close();status('Studio project saved. Your previous save is also kept as a recovery copy.');
  } catch(e) { status(`Could not save project: ${e.message}`,true); }
}
async function loadStudioProject() {
  try {
    const db=await openStudioDB();
    const project=await new Promise((resolve,reject)=>{
      const tx=db.transaction('projects','readonly'),store=tx.objectStore('projects'),req=store.get('current');
      req.onsuccess=()=>{if(req.result){resolve({project:req.result,recovered:false});return;}const backup=store.get('previous');backup.onsuccess=()=>resolve({project:backup.result,recovered:!!backup.result});backup.onerror=()=>reject(backup.error);};
      req.onerror=()=>reject(req.error);
    });db.close();
    if(!project.project) { status('No saved studio project or recovery copy was found on this device.',true); return; }
    const recovered=project.recovered;const savedProject=project.project;
    studio.bpm=savedProject.bpm||110;studio.pattern=savedProject.pattern||studio.pattern;studio.trackTakes=savedProject.takes||{vocals:[],piano:[],drums:[]};studio.trackMix=savedProject.trackMix||studio.trackMix;studio.trackMuted=savedProject.trackMuted||studio.trackMuted;studio.trackSolo=savedProject.trackSolo||studio.trackSolo;studio.trackPan=savedProject.trackPan||studio.trackPan;studio.undoStack=[];studio.redoStack=[];
    $('bpm').value=studio.bpm;$('bpmValue').textContent=`${studio.bpm} BPM`;buildSequencer();renderTrackTakes();status(recovered?'Recovery copy loaded. Save the project again to make it the current version.':'Saved studio project loaded on this device.');
  } catch(e) { status(`Could not load project: ${e.message}`,true); }
}
function cloneTrackTakes(source=studio.trackTakes) {
  return Object.fromEntries(Object.entries(source).map(([track,takes])=>[track,takes.map(take=>({...take}))]));
}
function captureEditState() {
  return {takes:cloneTrackTakes(),trackMix:{...studio.trackMix},trackMuted:{...studio.trackMuted},trackSolo:{...studio.trackSolo},trackPan:{...studio.trackPan}};
}
function restoreEditState(snapshot) {
  studio.trackTakes=cloneTrackTakes(snapshot.takes);
  studio.trackMix={...snapshot.trackMix};studio.trackMuted={...snapshot.trackMuted};
  studio.trackSolo={...snapshot.trackSolo};studio.trackPan={...snapshot.trackPan};
  renderTrackTakes();
}
function beginEdit(label) {
  studio.undoStack.push({label,state:captureEditState()});
  if(studio.undoStack.length>studio.historyLimit)studio.undoStack.shift();
  studio.redoStack=[];updateHistoryButtons();
}
function updateHistoryButtons() {
  const undo=$('studioUndo'),redo=$('studioRedo');
  if(undo)undo.disabled=!studio.undoStack.length;
  if(redo)redo.disabled=!studio.redoStack.length;
}
function undoStudioEdit() {
  if(!studio.undoStack.length)return;
  const entry=studio.undoStack.pop();studio.redoStack.push({label:entry.label,state:captureEditState()});
  restoreEditState(entry.state);updateHistoryButtons();status(`Undid: ${entry.label}.`);
}
function redoStudioEdit() {
  if(!studio.redoStack.length)return;
  const entry=studio.redoStack.pop();studio.undoStack.push({label:entry.label,state:captureEditState()});
  restoreEditState(entry.state);updateHistoryButtons();status(`Redid: ${entry.label}.`);
}
function splitTake(track,index,sourceTime) {
  const take=studio.trackTakes[track]?.[index];
  if(!take)return status('That recording take could not be found.',true);
  const duration=Number(take.duration)||0,trimStart=Number(take.trimStart)||0,trimEnd=Number(take.trimEnd)||duration;
  const cut=Number(sourceTime);
  if(!Number.isFinite(cut)||cut<=trimStart+.05||cut>=trimEnd-.05){
    status(`Choose a split point between ${trimStart.toFixed(1)} and ${trimEnd.toFixed(1)} seconds.`,true);return;
  }
  beginEdit(`split ${track} take`);
  const left={...take,trimEnd:cut};
  const right={...take,trimStart:cut,startAt:Math.max(0,(Number(take.startAt)||0)+(cut-trimStart))};
  studio.trackTakes[track].splice(index,1,left,right);
  renderTrackTakes();status(`${track} take split into two editable clips.`);
}
function renderArrangementTimeline() {
  const root=$('arrangementTimeline');if(!root)return;
  root.innerHTML='';
  const tracks=['vocals','piano','drums'];
  const labels={vocals:'Vocals',piano:'Piano',drums:'Drums'};
  const maxEnd=Math.max(10,...tracks.flatMap(t=>studio.trackTakes[t].map(take=>(Number(take.startAt)||0)+Math.max(.05,(Number(take.trimEnd)||Number(take.duration)||1)-(Number(take.trimStart)||0)))));
  const scale=Math.min(300,Math.max(10,Math.ceil(maxEnd/5)*5));
  const ruler=document.createElement('div');ruler.className='timeline-ruler';
  for(let sec=0;sec<=scale;sec+=5){const tick=document.createElement('span');tick.textContent=`${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`;tick.style.left=`${sec/scale*100}%`;ruler.append(tick);}root.append(ruler);
  tracks.forEach(track=>{
    const lane=document.createElement('div');lane.className='timeline-lane';
    const label=document.createElement('b');label.textContent=labels[track];lane.append(label);
    const rail=document.createElement('div');rail.className='timeline-rail';
    studio.trackTakes[track].forEach((take,index)=>{
      const clip=document.createElement('div');clip.className='timeline-clip';
      const left=Math.max(0,Number(take.startAt)||0);const duration=Math.max(.05,(Number(take.trimEnd)||Number(take.duration)||1)-(Number(take.trimStart)||0));
      clip.style.left=`${Math.min(99,left/scale*100)}%`;clip.style.width=`${Math.max(1.2,Math.min(100-left/scale*100,duration/scale*100))}%`;
      clip.textContent=`Take ${index+1}`;clip.title=`${labels[track]} take ${index+1}`;rail.append(clip);
    });
    lane.append(rail);root.append(lane);
  });
}
function renderTrackTakes() {
  const root=$('trackTakes');if(!root)return;
  root.innerHTML='';
  const labels={vocals:'🎙️ Vocal track',piano:'🎹 Piano track',drums:'🥁 Drum track'};
  Object.entries(studio.trackTakes).forEach(([track,takes])=>{
    const section=document.createElement('section');section.className='track-lane';
    const head=document.createElement('div');head.className='track-lane-head';
    const title=document.createElement('b');title.textContent=labels[track]||track;
    const controls=document.createElement('div');controls.className='track-mix-controls';
    const armLabel=document.createElement('label');armLabel.className='arm-label';const arm=document.createElement('input');arm.type='checkbox';arm.checked=!!studio.armedTracks[track];arm.addEventListener('change',()=>studio.armedTracks[track]=arm.checked);armLabel.append(arm,document.createTextNode(' Arm for recording'));
    const muteLabel=document.createElement('label');muteLabel.className='arm-label';const mute=document.createElement('input');mute.type='checkbox';mute.checked=!!studio.trackMuted[track];mute.addEventListener('change',()=>{studio.trackMuted[track]=mute.checked;});muteLabel.append(mute,document.createTextNode(' Mute in arrangement'));
    const volLabel=document.createElement('label');volLabel.className='track-volume';volLabel.textContent='Level';const vol=document.createElement('input');vol.type='range';vol.min='0';vol.max='150';vol.value=String(Math.round((studio.trackMix[track]??1)*100));vol.addEventListener('input',()=>{studio.trackMix[track]=Number(vol.value)/100;volLabel.lastChild.textContent=` ${vol.value}%`;});volLabel.append(vol,document.createTextNode(` ${vol.value}%`));
    const soloLabel=document.createElement('label');soloLabel.className='arm-label';const solo=document.createElement('input');solo.type='checkbox';solo.checked=!!studio.trackSolo[track];solo.addEventListener('change',()=>{studio.trackSolo[track]=solo.checked;});soloLabel.append(solo,document.createTextNode(' Solo'));
    const panLabel=document.createElement('label');panLabel.className='track-volume';panLabel.textContent='Pan';const pan=document.createElement('input');pan.type='range';pan.min='-100';pan.max='100';pan.value=String(Math.round((studio.trackPan[track]||0)*100));pan.addEventListener('input',()=>{studio.trackPan[track]=Number(pan.value)/100;panLabel.lastChild.textContent=` ${pan.value<0?'L '+Math.abs(pan.value):pan.value>0?'R '+pan.value:'Centre'}`;});panLabel.append(pan,document.createTextNode(pan.value==='0'?' Centre':` ${pan.value}%`));
    controls.append(armLabel,muteLabel,soloLabel,volLabel,panLabel);head.append(title,controls);section.append(head);
    if(!takes.length){const empty=document.createElement('p');empty.className='muted';empty.textContent='No takes recorded yet.';section.append(empty);}
    takes.forEach((take,index)=>{
      const row=document.createElement('div');row.className='take-row';
      const name=document.createElement('span');name.textContent=`Take ${index+1} · ${(take.blob.size/1024/1024).toFixed(2)} MB`;
      const audio=document.createElement('audio');audio.controls=true;audio.preload='none';audio.src=URL.createObjectURL(take.blob);
      const offsetLabel=document.createElement('label');offsetLabel.className='clip-offset';offsetLabel.textContent='Start (sec)';const offset=document.createElement('input');offset.type='number';offset.min='0';offset.max='300';offset.step='0.1';offset.value=String(Number(take.startAt)||0);offset.addEventListener('change',()=>{const next=Math.max(0,Math.min(300,Number(offset.value)||0));if(next!==Number(take.startAt||0)){beginEdit('move clip');take.startAt=next;}offset.value=String(take.startAt);renderArrangementTimeline();updateHistoryButtons();});offsetLabel.append(offset);
      const trimLabel=document.createElement('label');trimLabel.className='clip-offset';trimLabel.textContent='Trim in / out (sec)';
      const trimIn=document.createElement('input');trimIn.type='number';trimIn.min='0';trimIn.step='0.1';trimIn.max=String(take.duration||300);trimIn.value=String(Number(take.trimStart)||0);trimIn.setAttribute('aria-label','Trim start seconds');
      const trimOut=document.createElement('input');trimOut.type='number';trimOut.min='0.1';trimOut.step='0.1';trimOut.max=String(take.duration||300);trimOut.value=String(Number(take.trimEnd)||take.duration||0);trimOut.setAttribute('aria-label','Trim end seconds');
      const applyTrim=()=>{const total=Number(take.duration)||0;const a=Math.max(0,Math.min(Math.max(0,total-.05),Number(trimIn.value)||0));const b=Math.max(a+.05,Math.min(total,Number(trimOut.value)||total));if(a!==Number(take.trimStart||0)||b!==Number(take.trimEnd||total)){beginEdit('trim clip');take.trimStart=a;take.trimEnd=b;}trimIn.value=String(a);trimOut.value=String(b);renderArrangementTimeline();updateHistoryButtons();};
      trimIn.addEventListener('change',applyTrim);trimOut.addEventListener('change',applyTrim);trimLabel.append(trimIn,trimOut);
      const download=document.createElement('a');download.className='secondary download-link';download.textContent='Download WAV';download.href=audio.src;download.download=`living-music-hub-${track}-take-${index+1}.wav`;
      const splitLabel=document.createElement('label');splitLabel.className='clip-offset';splitLabel.textContent='Split at (source sec)';const splitAt=document.createElement('input');splitAt.type='number';splitAt.min='0';splitAt.max=String(take.duration||300);splitAt.step='0.1';splitAt.placeholder='e.g. 5.0';splitAt.setAttribute('aria-label',`Split ${track} take at source time in seconds`);splitLabel.append(splitAt);
      const split=document.createElement('button');split.type='button';split.className='secondary';split.textContent='Split clip';split.addEventListener('click',()=>splitTake(track,index,splitAt.value));
      const remove=document.createElement('button');remove.type='button';remove.className='secondary';remove.textContent='Delete';remove.addEventListener('click',()=>{beginEdit('delete clip');studio.trackTakes[track].splice(index,1);renderTrackTakes();updateHistoryButtons();});
      row.append(name,audio,offsetLabel,trimLabel,splitLabel,split,download,remove);section.append(row);
    });root.append(section);
  });
  renderArrangementTimeline();
}
async function decodeTake(take) {
  if(decodedTakeCache.has(take))return decodedTakeCache.get(take);
  const ctx=ensureAudio(),buffer=await ctx.decodeAudioData(await take.blob.arrayBuffer());
  take.duration=buffer.duration;if(take.trimStart==null)take.trimStart=0;if(take.trimEnd==null)take.trimEnd=buffer.duration;decodedTakeCache.set(take,buffer);return buffer;
}
async function playArrangement() {
  try {
    stopArrangement();ensureAudio();
    const jobs=[];
    for(const [track,takes] of Object.entries(studio.trackTakes)){
      if(studio.trackMuted[track] || (Object.values(studio.trackSolo).some(Boolean) && !studio.trackSolo[track]))continue;
      for(const take of takes)jobs.push({track,take,buffer:await decodeTake(take)});
    }
    if(!jobs.length)throw new Error('Record at least one track take before playing an arrangement.');
    const start=studio.ctx.currentTime+.08;
    jobs.forEach(({track,take,buffer})=>{
      const source=studio.ctx.createBufferSource(),gain=studio.ctx.createGain(),pan=studio.ctx.createStereoPanner();
      const trimStart=Math.max(0,Number(take.trimStart)||0),trimEnd=Math.min(buffer.duration,Number(take.trimEnd)||buffer.duration),playDuration=Math.max(0,trimEnd-trimStart);
      if(!playDuration) return;source.buffer=buffer;gain.gain.value=studio.trackMix[track]??1;pan.pan.value=studio.trackPan[track]??0;source.connect(gain);gain.connect(pan);pan.connect(studio.master);
      source.start(start+(Number(take.startAt)||0),trimStart,playDuration);studio.arrangementSources.push(source);
      source.onended=()=>{studio.arrangementSources=studio.arrangementSources.filter(item=>item!==source);if(!studio.arrangementSources.length){studio.arrangementPlaying=false;$('arrangementStop').disabled=true;$('arrangementPlay').disabled=false;}};
    });
    studio.arrangementPlaying=true;$('arrangementPlay').disabled=true;$('arrangementStop').disabled=false;
    status('Playing your multitrack arrangement.');
  }catch(e){status(e.message||'Could not play arrangement.',true);}
}
function stopArrangement() {
  studio.arrangementSources.forEach(source=>{try{source.stop();}catch(_){}});
  studio.arrangementSources=[];studio.arrangementPlaying=false;
  if($('arrangementPlay'))$('arrangementPlay').disabled=false;
  if($('arrangementStop'))$('arrangementStop').disabled=true;
}
function audioBufferToWav(buffer) {
  const channels=2,rate=buffer.sampleRate,frames=buffer.length;
  const out=new ArrayBuffer(44+frames*channels*2),view=new DataView(out);
  const write=(offset,str)=>{for(let i=0;i<str.length;i++)view.setUint8(offset+i,str.charCodeAt(i));};
  write(0,'RIFF');view.setUint32(4,36+frames*channels*2,true);write(8,'WAVE');write(12,'fmt ');
  view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,channels,true);view.setUint32(24,rate,true);view.setUint32(28,rate*channels*2,true);view.setUint16(32,channels*2,true);view.setUint16(34,16,true);write(36,'data');view.setUint32(40,frames*channels*2,true);
  const left=buffer.getChannelData(0),right=buffer.numberOfChannels>1?buffer.getChannelData(1):left;let offset=44;
  for(let i=0;i<frames;i++)for(const sample0 of [left[i],right[i]]){const sample=Math.max(-1,Math.min(1,sample0));view.setInt16(offset,sample<0?sample*32768:sample*32767,true);offset+=2;}
  return new Blob([out],{type:'audio/wav'});
}
async function exportArrangement() {
  const button=$('arrangementExport');
  try {
    button.disabled=true;button.textContent='Preparing WAV…';
    const jobs=[];let duration=0;
    for(const [track,takes] of Object.entries(studio.trackTakes)){
      if(studio.trackMuted[track] || (Object.values(studio.trackSolo).some(Boolean) && !studio.trackSolo[track]))continue;
      for(const take of takes){const buffer=await decodeTake(take),start=Math.max(0,Number(take.startAt)||0),trimStart=Math.max(0,Number(take.trimStart)||0),trimEnd=Math.min(buffer.duration,Number(take.trimEnd)||buffer.duration),playDuration=Math.max(0,trimEnd-trimStart);if(playDuration){jobs.push({track,buffer,start,trimStart,playDuration});duration=Math.max(duration,start+playDuration);}}
    }
    if(!jobs.length)throw new Error('There are no unmuted takes to export.');
    if(duration>300)throw new Error('For reliable mobile export, keep each arrangement to five minutes or less for now.');
    const rate=44100,offline=new OfflineAudioContext(2,Math.ceil((duration+.1)*rate),rate);
    const master=offline.createGain();
    master.gain.value=studio.master?.gain.value ?? Number($('mixMaster')?.value ?? 80)/100;
    master.connect(offline.destination);
    jobs.forEach(({track,buffer,start,trimStart,playDuration})=>{const src=offline.createBufferSource(),gain=offline.createGain(),pan=offline.createStereoPanner();src.buffer=buffer;gain.gain.value=studio.trackMix[track]??1;pan.pan.value=studio.trackPan[track]??0;src.connect(gain);gain.connect(pan);pan.connect(master);src.start(start,trimStart,playDuration);});
    const rendered=await offline.startRendering(),blob=audioBufferToWav(rendered),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download='living-music-hub-multitrack-arrangement.wav';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
    status(`Arrangement exported as stereo WAV · ${Math.floor(duration/60)}:${String(Math.floor(duration%60)).padStart(2,'0')}.`);
  }catch(e){status(e.message||'Could not export arrangement.',true);}
  finally{button.disabled=false;button.textContent='Export arrangement WAV';}
}
function hasRecordedSignal(buffer) {
  let peak=0;
  for(let channel=0;channel<buffer.numberOfChannels;channel++){
    const data=buffer.getChannelData(channel),stride=Math.max(1,Math.floor(data.length/12000));
    for(let i=0;i<data.length;i+=stride)peak=Math.max(peak,Math.abs(data[i]));
  }
  return peak>0.0005;
}
function startTrackRecorders() {
  studio.trackRecorders={};studio.trackChunks={};
  Object.entries(studio.trackDests).forEach(([track,destination])=>{
    if(!studio.armedTracks[track])return;
    if(track==='vocals'&&!studio.micStream){status('Vocal track skipped because the microphone is off. Enable the microphone and arm Vocals to record a vocal take.');return;}
    const mimeType=chooseRecorderType();const recorder=new MediaRecorder(destination.stream,mimeType?{mimeType}:undefined);
    studio.trackChunks[track]=[];recorder.ondataavailable=e=>{if(e.data?.size)studio.trackChunks[track].push(e.data);};
    recorder.onerror=(event)=>status(`${track} recorder error: ${event.error?.message||'audio capture failed'}`,true);
    recorder.onstop=async()=>{
      try {
        const raw=new Blob(studio.trackChunks[track],{type:recorder.mimeType||'audio/webm'});
        if(!raw.size)return;
        const wav=await makeWav(raw),decoded=await ensureAudio().decodeAudioData(await wav.arrayBuffer());
        if(!hasRecordedSignal(decoded)){status(`${track} track contained no audible signal, so an empty take was not added.`);return;}
        studio.trackTakes[track].push({blob:wav,createdAt:new Date().toISOString(),startAt:0,duration:decoded.duration,trimStart:0,trimEnd:decoded.duration});renderTrackTakes();
      }catch(e){status(`Could not prepare ${track} take: ${e.message}`,true);}
    };
    recorder.start(250);studio.trackRecorders[track]=recorder;
  });
}
function stopTrackRecorders() { Object.values(studio.trackRecorders).forEach(recorder=>{if(recorder.state!=='inactive')recorder.stop();}); }

function startRecording() {
  try {
    ensureAudio(); const mimeType=chooseRecorderType();
    studio.chunks=[];studio.lastBlob=null;$('useMix').disabled=true;$('studioPreviewWrap').classList.add('hidden');
    if(studio.lastUrl){URL.revokeObjectURL(studio.lastUrl);studio.lastUrl=null;}
    studio.recorder=new MediaRecorder(studio.recordDest.stream,mimeType?{mimeType}:undefined);
    studio.recorder.ondataavailable=(e)=>{if(e.data?.size)studio.chunks.push(e.data);};
    studio.recorder.onerror=(event)=>{
      clearRecordingTimer();studio.isRecording=false;
      $('recordStart').disabled=false;$('recordStop').disabled=true;
      status(event.error?.message||'The browser reported a recording error. Try again in Chrome.',true);
    };
    studio.recorder.onstop=async()=>{
      clearRecordingTimer();studio.isRecording=false;
      try {
        const elapsed=formatTime(Date.now()-studio.recordingStartedAt);
        const raw=new Blob(studio.chunks,{type:studio.recorder.mimeType||'audio/webm'});
        if(!raw.size) throw new Error('No audio data was captured. Check microphone permission and try again.');
        status('Preparing your studio mix as a mobile-friendly WAV file…');
        studio.lastBlob=await makeWav(raw);
        if(studio.lastUrl)URL.revokeObjectURL(studio.lastUrl);studio.lastUrl=URL.createObjectURL(studio.lastBlob);
        $('studioPreview').src=studio.lastUrl;$('studioPreviewWrap').classList.remove('hidden');
        $('recordingInfo').textContent=`WAV ready · ${elapsed} · ${(studio.lastBlob.size/1024/1024).toFixed(2)} MB · 22.05 kHz mono`;
        $('downloadMix').href=studio.lastUrl;$('downloadMix').download='living-music-hub-studio-mix.wav';
        $('useMix').disabled=false;status('Recording finished. Preview, download or attach your WAV mix to an artist submission.');
      } catch(e) { status(`Could not prepare the recording: ${e.message||'unsupported audio format'}`,true); }
      finally {$('recordStart').disabled=false;$('recordStop').disabled=true;}
    };
    studio.recorder.start(250);startTrackRecorders();studio.isRecording=true;studio.recordingStartedAt=Date.now();
    $('recordStart').disabled=true;$('recordStop').disabled=false;
    $('recordingInfo').textContent='Recording · 00:00';
    studio.recordingTimer=setInterval(()=>{$('recordingInfo').textContent=`Recording · ${formatTime(Date.now()-studio.recordingStartedAt)}`;},500);
    status('Recording your live mix. Play the keyboard, trigger drum pads or start the beat.');
  }catch(e){status(e.message||'Could not start recording.',true);}
}
function stopRecording() {
  if(studio.recorder&&studio.recorder.state!=='inactive'){
    $('recordStop').disabled=true;
    $('recordingInfo').textContent='Finishing recording…';
    studio.recorder.stop();stopTrackRecorders();studio.isRecording=false;
  }
}
function useMixForUpload() {
  if(!studio.lastBlob)return;
  const ext='wav';
  const file=new File([studio.lastBlob],`living-music-hub-studio-mix.${ext}`,{type:'audio/wav'});
  const input=$('uploadForm')?.elements.audio;
  if(!input)return;
  const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;
  document.querySelector('#upload').scrollIntoView({behavior:'smooth'});
  const title=$('uploadForm').elements.title;if(title&&!title.value)title.value='My Studio Recording';
  const note=$('uploadStatus');if(note)note.textContent='Studio mix attached. Add your song details and rights confirmation, then submit for review.';
}
function bindMixers() {
  [['mixMaster','master'],['mixMic','micGain'],['mixKeys','keysGain'],['mixDrums','drumsGain']].forEach(([id,key])=>$(id).addEventListener('input',e=>{
    if(studio[key])studio[key].gain.setTargetAtTime(Number(e.target.value)/100,studio.ctx.currentTime,.015);
    $(`${id}Value`).textContent=`${e.target.value}%`;
  }));
}
function init() {
  buildKeyboard();buildSequencer();bindMixers();
  document.querySelectorAll('[data-drum]').forEach(p=>p.addEventListener('pointerdown',e=>{e.preventDefault();drum(p.dataset.drum);}));
  $('micToggle').addEventListener('click',toggleMic);
  $('beatPlay').addEventListener('click',()=>studio.sequencerTimer?stopBeat():startBeat());
  $('bpm').addEventListener('input',e=>{studio.bpm=Number(e.target.value);$('bpmValue').textContent=`${studio.bpm} BPM`;if(studio.sequencerTimer)startBeat();});
  $('recordStart').addEventListener('click',startRecording);$('recordStop').addEventListener('click',stopRecording);$('useMix').addEventListener('click',useMixForUpload);
  $('saveStudioProject')?.addEventListener('click',saveStudioProject);$('loadStudioProject')?.addEventListener('click',loadStudioProject);$('arrangementPlay')?.addEventListener('click',playArrangement);$('arrangementStop')?.addEventListener('click',stopArrangement);$('arrangementExport')?.addEventListener('click',exportArrangement);$('studioUndo')?.addEventListener('click',undoStudioEdit);$('studioRedo')?.addEventListener('click',redoStudioEdit);
  const setMode=(mode)=>{document.body.dataset.studioMode=mode;const easy=mode==='easy';$('easyModeBtn').classList.toggle('primary',easy);$('easyModeBtn').classList.toggle('secondary',!easy);$('proModeBtn').classList.toggle('primary',!easy);$('proModeBtn').classList.toggle('secondary',easy);$('easyModeBtn').setAttribute('aria-pressed',String(easy));$('proModeBtn').setAttribute('aria-pressed',String(!easy));$('studioModeNote').textContent=easy?'Easy mode: a clear recording workflow with essential instruments and a simple mix.':'Advanced mode: separate tracks, timeline arrangement, detailed mixer and beat sequencing.';};
  $('easyModeBtn')?.addEventListener('click',()=>setMode('easy'));$('proModeBtn')?.addEventListener('click',()=>setMode('pro'));setMode('easy');renderTrackTakes();updateHistoryButtons();
  $('downloadMix').addEventListener('click',()=>{if(!studio.lastBlob)status('Make a recording first.',true);});
  $('saveMixToCloud')?.addEventListener('click',async()=>{const button=$('saveMixToCloud');if(!studio.lastBlob){status('Make a recording first.',true);return;}button.disabled=true;try{const result=await window.LMHCloudLibrary?.saveProjectFile({blob:studio.lastBlob,fileName:'living-music-hub-studio-mix.wav',division:'music_production'});if(!result)throw new Error('Cloud library is not ready. Sign in and try again.');status('Studio WAV saved to your shared private cloud workspace.');}catch(e){status(e.message||'Could not save studio mix to cloud.',true);}finally{button.disabled=false;}});
  window.addEventListener('beforeunload',()=>{stopBeat();stopArrangement();studio.micStream?.getTracks().forEach(t=>t.stop());});
}
init();
