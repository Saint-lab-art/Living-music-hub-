# Upload instructions — separate development only

1. Keep the original `main` branch unchanged.
2. Create or select a separate branch named `studio/multitrack-development` (or another clearly named studio development branch).
3. Extract this ZIP and upload the CONTENTS of this folder to the repository root on that development branch. Include hidden files such as `.nojekyll`.
4. Commit to the development branch only. Do not commit this build to `main`.
5. Confirm the GitHub Pages workflow succeeds and test the hosted development preview before any merge is considered.

If GitHub refuses branch creation or file commits, the connected GitHub integration needs repository write access. Grant the connected app the required repository Contents and Metadata permissions, or perform the upload manually while signed in as an authorized repository collaborator. Never share a password, personal access token or secret key in chat.

The build has passed static syntax and feature checks, but it has NOT passed physical microphone, Android latency or full browser end-to-end testing. Do not announce it as production-ready until those tests pass.
