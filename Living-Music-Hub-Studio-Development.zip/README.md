# Living Music Hub — Studio Development Build

A separate development build for the approved dual-mode studio and first multitrack editing milestone.

## Studio modes
- **Easy Music Studio** — simplified recording workflow.
- **Advanced Professional Studio** — separate vocal, piano and drum lanes, arrangement timeline, clip editing and mix controls.

## Multitrack features
- Record separate vocal, piano and drum takes.
- Arrange takes with start-time offsets.
- Non-destructive trim-in / trim-out.
- Track arm, mute, solo, level and stereo pan.
- Synchronized arrangement playback and stereo WAV export (five-minute limit in this build).
- Save and load the current project locally on the device.

## Run locally
Serve this folder over localhost or HTTPS and open `index.html` in a current browser. Microphone recording requires HTTPS (or localhost) and user permission.

## Important limitations
This is a development build, not a deployed or production-ready release. It still needs physical microphone and Android testing. Cloud sync, automation and effects racks are not included. The original project and `main` branch must remain untouched until a separate development preview has been tested and approved.

See `STUDIO-STATUS.md` and `DEVELOPMENT-UPLOAD-INSTRUCTIONS.md`.
