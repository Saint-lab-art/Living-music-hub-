const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const js = fs.readFileSync('photo-video.js', 'utf8');
const sw = fs.readFileSync('sw.js', 'utf8');
const requiredIds = ['designCanvas','designImage','designSize','designHeadline','designDownload','movieFiles','moviePreview','movieClipList','movieSave','movieNotes'];
for (const id of requiredIds) {
  if (!html.includes(`id="${id}"`)) throw new Error(`Missing HTML control: ${id}`);
}
if (!html.includes('src="photo-video.js"')) throw new Error('Photo/video module not loaded');
if (!sw.includes("'./photo-video.js'")) throw new Error('Photo/video module missing from app shell cache');
for (const token of ['toBlob','createObjectURL','movieClipList','localStorage']) {
  if (!js.includes(token)) throw new Error(`Missing expected local workflow: ${token}`);
}
console.log('PASS: photo studio controls and PNG export are wired in the build');
console.log('PASS: movie footage import, preview and local project notes are wired in the build');
console.log('PASS: photo/video module is referenced by the page and service-worker app shell');
