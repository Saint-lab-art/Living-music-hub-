# Living Music Hub — Canonical Development Source v1.0

Prepared: 21 November 2026

## Canonical selection

This source is based on `Living-Music-Hub-Independent-Development-v4.zip` (uploaded 20 November 2026). It is selected because it is the most complete integrated application package currently available in the project library: it includes the music platform, multitrack music studio, Photo & Picture Designing Studio, and Movie Production Studio foundation.

The latest `Living-Music-Hub-Studio-Development-v2-2.zip` (21 November 2026) contains additional music-studio recording hardening, but it predates the integrated photo/video workspace and uses an earlier page structure. It is retained as a reference, not overlaid blindly, because a direct replacement could remove v4 UI functionality or undo/redo support.

## Preservation rule

- This package is a separate development baseline.
- Do not overwrite the original GitHub `main` branch.
- Keep the existing master project archive and prior ZIP versions unchanged.
- Proposed GitHub target: `development/canonical-source-v1`.
- GitHub branch creation was blocked by the connected integration (HTTP 403); this package has not been pushed to GitHub.

## Included source

- `index.html`, `app.js`, `studio.js`, `photo-video.js`, `styles.css`
- `config.js` (public Supabase project URL and publishable key only)
- PWA manifest, icons, service worker, `.nojekyll`
- Studio and independent-build smoke tests
- Scope, revenue, development and deployment documentation

## Current limits

This is the best integrated development source identified in the available packages. It is not a production certification. Supabase schema/RLS and storage policies require live verification; payments are not implemented; physical-device and full browser tests remain outstanding. Movie production is an early footage-bin/storyboard foundation, not a finished video editor. Photo design is a basic canvas editor, not a full professional graphics suite.
