# Living Music Hub — Independent Development Build v4

This is a separate independent development build. It does not require GitHub and must not overwrite the original project.

## Included workspaces
- Music discovery, listener account, artist submission and review interface (backend connection and policies still require live verification).
- Easy Music Studio and Advanced Professional Studio.
- Multitrack vocal, piano and drum recording/editing, clip movement/splitting/trimming, undo/redo, mixer controls, arrangement playback and WAV export.
- Photo & Picture Designing Studio: local image import, canvas sizes, background colour, headline/supporting text, layout position and PNG export.
- Movie Production Studio foundation: local video import, clip preview, clip ordering, removal, title overlay and storyboard/project notes saved locally.

## Run locally
Serve this folder over localhost or HTTPS and open `index.html` in a current browser. Microphone recording requires HTTPS (or localhost) and user permission. The photo editor uses the browser canvas. Video files remain local to the current browser session; only project notes and clip names are saved locally.

## Important limitations
This is a development build, not a deployed or production-ready release. The movie workspace is an early footage-bin and storyboard foundation: it does not yet provide a multi-track video timeline, trimming/rendering, audio mixing, transitions, effects or final video export. The photo studio is a basic canvas designer, not yet a full professional graphics suite. Physical Android microphone/video tests, browser end-to-end tests, backend security review and payment integration remain outstanding.

The original project must remain untouched. Develop and test this folder independently. Never put secrets in browser source code or publish unreviewed creator uploads.
