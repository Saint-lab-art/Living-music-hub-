# Release gates — do not skip

## Before public launch
- [ ] Verify Supabase project ownership, URL and publishable key; no service-role key in browser code.
- [ ] Verify schema, foreign keys, indexes, Row Level Security and Storage policies against every query in `app.js`.
- [ ] Confirm admin role is enforced by database policies/server-side controls, not merely hidden UI.
- [ ] Test registration, email confirmation, sign-in, reset, sign-out and session refresh.
- [ ] Test artist profile create/update, audio upload limits, pending moderation, approve/reject, playback and takedown.
- [ ] Test favourites and signed audio URLs with two separate accounts.
- [ ] Test multitrack capture, clip move/trim/split, undo/redo, project save/load and WAV export on Android Chrome and desktop.
- [ ] Test photo import, canvas editing and PNG export on mobile and desktop.
- [ ] Test video file import, playback, clip ordering and notes; document browser/file-size limits.
- [ ] Test PWA install, offline fallback, cache update and recovery.
- [ ] Add privacy policy, terms, copyright/takedown process and content moderation procedures.
- [ ] Decide and document the video revenue share before payout code. Earlier approval was 70%/30%; a later project document says 65%/35%. Do not implement payouts until reconciled.
- [ ] Implement and test payment processing, ledger, reconciliation and payout workflows before charging users.
- [ ] Complete backups, restore drill, monitoring, error logging and rollback plan.
- [ ] Run accessibility, security, dependency and end-to-end tests.
- [ ] Deploy to a separate preview environment and obtain release approval before merge to main.

## Known feature boundaries
- Music studio: multitrack foundation exists; effects racks, automation, cloud sync and collaboration remain future work.
- Photo studio: basic canvas, image import and PNG export exist; layers, templates, advanced crop/resize, project persistence and richer typography remain.
- Movie studio: local footage preview/order and storyboard notes exist; full timeline, trimming/rendering, audio mixing, transitions and final video export remain.
