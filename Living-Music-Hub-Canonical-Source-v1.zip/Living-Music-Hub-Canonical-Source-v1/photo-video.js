const byId = (id) => document.getElementById(id);

// Photo design studio: a small, local canvas-based composition tool.
const canvas = byId('designCanvas');
const ctx = canvas.getContext('2d');
let designImage = null;
function drawArtwork() {
  if (!canvas || !ctx) return;
  const bg = byId('designBg').value;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (designImage) {
    const scale = Math.max(canvas.width / designImage.width, canvas.height / designImage.height);
    const w = designImage.width * scale, h = designImage.height * scale;
    ctx.drawImage(designImage, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
    ctx.fillStyle = 'rgba(4, 9, 18, .42)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  const headline = byId('designHeadline').value.trim();
  const subline = byId('designSubline').value.trim();
  const color = byId('designTextColor').value;
  const position = byId('designPosition').value;
  const centerY = position === 'top' ? canvas.height * .25 : position === 'middle' ? canvas.height * .52 : canvas.height * .76;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = color;
  ctx.shadowColor = 'rgba(0,0,0,.7)'; ctx.shadowBlur = Math.max(5, canvas.width * .008);
  const headlineSize = Math.round(canvas.width * .075);
  ctx.font = `900 ${headlineSize}px system-ui, sans-serif`;
  wrapText(ctx, headline, canvas.width * .84, centerY, headlineSize * 1.15);
  ctx.font = `600 ${Math.round(canvas.width * .032)}px system-ui, sans-serif`;
  wrapText(ctx, subline, canvas.width * .82, centerY + headlineSize * 1.5, Math.round(canvas.width * .045));
  ctx.shadowBlur = 0;
  byId('designStatus').textContent = 'Artwork updated. Export PNG to save a copy on your device.';
}
function wrapText(context, text, maxWidth, y, lineHeight) {
  if (!text) return;
  const words = text.split(/\s+/); let line = ''; const lines = [];
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (context.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
    else line = test;
  }
  if (line) lines.push(line);
  const start = y - ((lines.length - 1) * lineHeight) / 2;
  lines.forEach((item, index) => context.fillText(item, canvas.width / 2, start + index * lineHeight, maxWidth));
}
byId('designImage').addEventListener('change', (event) => {
  const file = event.target.files?.[0]; if (!file) return;
  if (!file.type.startsWith('image/')) { byId('designStatus').textContent = 'Please select a valid image file.'; return; }
  const url = URL.createObjectURL(file); const image = new Image();
  image.onload = () => { if (designImage?.src?.startsWith('blob:')) URL.revokeObjectURL(designImage.src); designImage = image; drawArtwork(); };
  image.onerror = () => { URL.revokeObjectURL(url); byId('designStatus').textContent = 'The selected image could not be opened.'; };
  image.src = url;
});
byId('designSize').addEventListener('change', () => {
  const [width, height] = byId('designSize').value.split(',').map(Number);
  canvas.width = width; canvas.height = height; drawArtwork();
});
['designBg','designHeadline','designSubline','designTextColor','designPosition'].forEach((id) => byId(id).addEventListener('input', drawArtwork));
byId('designRender').addEventListener('click', drawArtwork);
byId('designDownload').addEventListener('click', () => {
  drawArtwork(); canvas.toBlob((blob) => {
    if (!blob) { byId('designStatus').textContent = 'PNG export failed. Please try again.'; return; }
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = 'living-music-hub-artwork.png'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    byId('designStatus').textContent = 'PNG export created.';
  }, 'image/png');
});
drawArtwork();

// Movie production workspace: local footage bin, preview and storyboard notes.
const movieFiles = [];
let activeMovieIndex = -1;
const movieVideo = byId('moviePreview');
function formatDuration(seconds) {
  if (!Number.isFinite(seconds)) return 'Duration unknown';
  return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
}
function renderMovieClips() {
  const list = byId('movieClipList');
  if (!movieFiles.length) { list.innerHTML = '<p class="muted">No clips imported yet.</p>'; return; }
  list.innerHTML = movieFiles.map((item, index) => `<div class="movie-clip ${index === activeMovieIndex ? 'active' : ''}"><div><b>${escapeText(item.file.name)}</b><small>${formatDuration(item.duration)} · ${(item.file.size / 1048576).toFixed(1)} MB</small></div><div class="movie-clip-actions"><button type="button" data-movie-open="${index}" class="secondary">Preview</button><button type="button" data-movie-up="${index}" class="secondary" ${index === 0 ? 'disabled' : ''}>↑</button><button type="button" data-movie-down="${index}" class="secondary" ${index === movieFiles.length - 1 ? 'disabled' : ''}>↓</button><button type="button" data-movie-remove="${index}" class="secondary">Remove</button></div></div>`).join('');
  list.querySelectorAll('[data-movie-open]').forEach((button) => button.addEventListener('click', () => openMovie(Number(button.dataset.movieOpen))));
  list.querySelectorAll('[data-movie-up]').forEach((button) => button.addEventListener('click', () => moveMovie(Number(button.dataset.movieUp), -1)));
  list.querySelectorAll('[data-movie-down]').forEach((button) => button.addEventListener('click', () => moveMovie(Number(button.dataset.movieDown), 1)));
  list.querySelectorAll('[data-movie-remove]').forEach((button) => button.addEventListener('click', () => removeMovie(Number(button.dataset.movieRemove))));
}
function escapeText(value) { return String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
function openMovie(index) {
  const item = movieFiles[index]; if (!item) return;
  activeMovieIndex = index; movieVideo.src = item.url; movieVideo.load(); renderMovieClips();
  byId('movieStatus').textContent = `Previewing ${item.file.name}.`;
}
function moveMovie(index, direction) {
  const target = index + direction; if (target < 0 || target >= movieFiles.length) return;
  [movieFiles[index], movieFiles[target]] = [movieFiles[target], movieFiles[index]];
  if (activeMovieIndex === index) activeMovieIndex = target; else if (activeMovieIndex === target) activeMovieIndex = index;
  renderMovieClips();
}
function removeMovie(index) {
  const [removed] = movieFiles.splice(index, 1); if (removed) URL.revokeObjectURL(removed.url);
  if (activeMovieIndex === index) { movieVideo.pause(); movieVideo.removeAttribute('src'); movieVideo.load(); activeMovieIndex = -1; }
  else if (activeMovieIndex > index) activeMovieIndex--;
  renderMovieClips(); byId('movieStatus').textContent = 'Clip removed from this workspace.';
}
byId('movieFiles').addEventListener('change', async (event) => {
  const selected = [...(event.target.files || [])];
  for (const file of selected) {
    if (!file.type.startsWith('video/')) continue;
    const url = URL.createObjectURL(file); const probe = document.createElement('video'); probe.preload = 'metadata'; probe.src = url;
    const duration = await new Promise((resolve) => {
      const done = () => resolve(probe.duration);
      probe.addEventListener('loadedmetadata', done, {once:true});
      probe.addEventListener('error', () => resolve(NaN), {once:true});
    });
    movieFiles.push({file, url, duration});
  }
  if (activeMovieIndex < 0 && movieFiles.length) openMovie(0); else renderMovieClips();
  byId('movieStatus').textContent = `${selected.length} file(s) selected. Footage is local and has not been uploaded.`;
  event.target.value = '';
});
byId('movieOverlayText').addEventListener('input', () => { byId('movieTitleOverlay').textContent = byId('movieOverlayText').value; });
byId('movieSave').addEventListener('click', () => {
  const project = {title:byId('movieProjectTitle').value, notes:byId('movieNotes').value, overlay:byId('movieOverlayText').value, clipNames:movieFiles.map((item) => item.file.name), savedAt:new Date().toISOString()};
  try { localStorage.setItem('lmh-movie-project-notes', JSON.stringify(project)); byId('movieStatus').textContent = 'Project notes saved on this device. Video files themselves are not copied into this notes file.'; }
  catch { byId('movieStatus').textContent = 'Could not save project notes in this browser. Export or copy your notes separately.'; }
});
byId('movieClear').addEventListener('click', () => {
  movieFiles.forEach((item) => URL.revokeObjectURL(item.url)); movieFiles.length = 0; activeMovieIndex = -1;
  movieVideo.pause(); movieVideo.removeAttribute('src'); movieVideo.load();
  byId('movieProjectTitle').value = ''; byId('movieOverlayText').value = ''; byId('movieTitleOverlay').textContent = ''; byId('movieNotes').value = '';
  renderMovieClips(); byId('movieStatus').textContent = 'Workspace cleared. Saved project notes remain on this device until overwritten.';
});
try {
  const saved = JSON.parse(localStorage.getItem('lmh-movie-project-notes') || 'null');
  if (saved) { byId('movieProjectTitle').value = saved.title || ''; byId('movieNotes').value = saved.notes || ''; byId('movieOverlayText').value = saved.overlay || ''; byId('movieTitleOverlay').textContent = saved.overlay || ''; }
} catch { /* Ignore malformed local project notes. */ }
