# Living Music Hub — Independent Project Roadmap

## Project preservation
1. Keep the original project archive unchanged.
2. Treat this v4 package as the independent development line.
3. Keep dated ZIP backups on the user's device and a second cloud location. Gmail is suitable for backup records and links; Google Drive is better for storing the actual ZIP files.
4. Keep configuration secrets out of ZIPs intended for public hosting. Use server-side secrets for privileged backend operations.

## Product workstreams

### A. Music platform
- Listener discovery, search, playback, favourites and accounts.
- Artist profile submission, rights declaration, review queue, publish/reject, takedown and appeals.
- Secure audio storage and delivery; admin preview of pending submissions.
- Creator analytics, statements and transparent rights/credits.

### B. Music production studio
- Easy and Advanced modes; multitrack recording and editing.
- Next: physical-device testing, effects, automation, mixer routing, autosave and reliable project export.
- Later: cloud project sync and collaboration after local reliability and permissions are verified.

### C. Photo / picture designing studio
- Current foundation: image import, canvas presets, text overlay and PNG export.
- Next: crop, resize, layers, shapes, text styling, templates, undo/redo and editable project files.

### D. Movie production studio
- Current foundation: local footage bin, preview, clip ordering and storyboard notes.
- Next: multi-track timeline, clip trimming, audio tracks, title cards, transitions, captions, rendering and downloadable video export.
- Later: team review, cloud storage and creator publishing after rights and storage controls are implemented.

### E. Distribution and monetisation
- Music/video/download distribution, transparent usage reporting and rights management.
- Do not implement payout calculations until the revenue-share decision is reconciled. The latest v3 policy file says 65% artist / 35% platform, while the user's earlier instruction approved 70% / 30%. Treat this as an unresolved decision, not an automatic change.
- Marketplace commissions are separate and remain undecided.
- Core platform access remains free at launch; no subscription billing without a new explicit decision.

### F. Independent hosting and operations
- Select a non-GitHub host and configure domain, HTTPS, environment variables, backups and rollback.
- Verify backend policies and upload restrictions before exposing any creator uploads publicly.
- Test on Android Chrome and desktop browsers, including low-memory devices and weak network conditions.

## Release gates
A workstream is not complete until its user-facing behaviour, security, mobile compatibility, accessibility, error handling, backup/restore and end-to-end tests have been verified. Source-level checks alone are not a release certification.
