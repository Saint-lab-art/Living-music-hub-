# Studio Development Status

This is a separate development package. It is not deployed to the public website and does not alter the original/main branch.

## Implemented in this package
- Easy Music Studio and Advanced Professional Studio mode switch.
- Existing microphone recording, 25-key piano, drum pads and 16-step beat sequencer.
- Separate vocal, piano and drum recording takes.
- Visual arrangement timeline with editable clip start positions.
- Non-destructive clip trim-in and trim-out controls.
- Per-track arm, mute, solo, level and stereo pan controls.
- Synchronized arrangement playback.
- Stereo WAV export with a five-minute safety limit.
- Local IndexedDB project save/load, including takes and arrangement settings.
- Expanded upload genres including country, reggae, rock and rhumba.
- Updated service-worker cache version for the development build.

## Latest corrective upgrade (v2)
- Vocal multitrack capture is skipped when the microphone is off, preventing a misleading empty vocal take.
- Silent/near-silent track recordings are discarded instead of being added as empty takes.
- Arrangement WAV export now passes through the same master-gain setting as arrangement playback.
- Saving a project retains the previous saved project as a local recovery copy; loading falls back to that copy if the current save is missing.
- Added Country, Rock, Rhumba, Jazz and Soul to the Discover genre filters.
- Service-worker cache version bumped to force the updated development assets to refresh.

## Verification completed
- JavaScript syntax checks pass for `studio.js` and `app.js`.
- Static feature checks pass for dual modes, three tracks, timeline, trim, mute/solo, level/pan, project save/load, genre filters and cache version.
- These are source/static checks only; they do not certify live microphone capture or Android audio performance.

## Still required before release
- Real microphone capture and audio-latency tests on Android Chrome and desktop browsers.
- Confirm independent vocals/piano/drums capture using actual recordings.
- Test save, close/reopen, load, playback, trim, solo, pan and WAV export with real audio.
- Test memory use and export reliability on lower-memory Android phones.
- Cloud project sync, effects racks, automation and collaboration.
- GitHub development-branch push and hosted preview.

## Important
The GitHub integration previously returned HTTP 403 for repository writes. No repository changes or deployment are included in this package. Do not upload this build to `main`; use a separate development branch only.
