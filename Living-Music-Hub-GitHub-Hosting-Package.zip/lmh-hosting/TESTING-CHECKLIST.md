# Living Music Hub — pre-launch test checklist

## 1. Public listener
- [ ] Open the site without signing in.
- [ ] Search by song title, artist and genre.
- [ ] Confirm only published songs appear.
- [ ] Play, pause, seek and skip tracks.
- [ ] Confirm a published track streams from the private bucket using a signed URL.
- [ ] Confirm favourites require sign-in and persist after signing back in.

## 2. Artist account and uploads
- [ ] Register a test artist account and confirm the email if requested.
- [ ] Save an artist profile.
- [ ] Upload an original MP3 or WAV with the rights declaration checked.
- [ ] Confirm the submission is marked pending and is not public.
- [ ] Confirm a second signed-out browser cannot stream the pending audio.
- [ ] Try a file larger than 50 MB and confirm it is rejected.
- [ ] Try an upload without the rights declaration and confirm it is rejected.

## 3. Music studio (Android Chrome recommended)
- [ ] Open Studio over HTTPS.
- [ ] Tap white and black piano keys across both octaves and confirm each note plays.
- [ ] Tap each drum pad and confirm the correct sound plays.
- [ ] Change BPM and play the sequencer.
- [ ] Change steps in the 16-step grid and confirm the rhythm changes.
- [ ] Adjust each mixer slider and confirm channel levels change.
- [ ] Allow microphone permission and test the microphone with headphones.
- [ ] Start recording, perform on the keyboard, trigger drums and speak/sing into the microphone.
- [ ] Confirm the recording timer advances, stop recording and wait for WAV conversion.
- [ ] Preview and download the WAV mix.
- [ ] Arm only Vocal, record a short test and confirm a vocal take appears separately.
- [ ] Arm only Piano, record a short test and confirm the piano take appears separately.
- [ ] Arm only Drums, record a short test and confirm the drum take appears separately.
- [ ] Preview, download and delete a take; confirm the other tracks remain intact.
- [ ] Save the studio project, reload the page, choose Load project and confirm takes/pattern/tempo return.
- [ ] Attach the mix to Artist Upload and submit it as a pending song.
- [ ] Confirm a long recording remains below the 50 MB upload limit; shorten it if necessary.

## 4. Administrator
- [ ] Create the owner account first.
- [ ] Verify the Auth user UUID in Supabase Dashboard.
- [ ] Add only that verified UUID to `public.admin_users` using the owner-only SQL instruction in `PUBLIC-LAUNCH-GUIDE.md`.
- [ ] Sign in as the administrator and confirm the moderation queue appears.
- [ ] Publish a test song and confirm it becomes visible in Discover.
- [ ] Reject another test song and confirm it remains unavailable publicly.

## 5. PWA and mobile
- [ ] Set the production HTTPS Site URL and allowed redirect URLs in Supabase Auth settings.
- [ ] Deploy the contents of this folder to an HTTPS static host.
- [ ] Install the PWA from Android Chrome.
- [ ] Reopen the installed app and test navigation, player and studio.
- [ ] Confirm the app icon displays the microphone and keyboard.

## 6. Before public launch
- [ ] Rotate the Supabase secret key previously exposed in a chat; do not place the replacement in this project.
- [ ] Publish a privacy policy and terms of use.
- [ ] Publish artist upload/distribution terms and copyright complaint/takedown procedure.
- [ ] Add a support contact and abuse-reporting process.
- [ ] Confirm backups, monitoring and recovery procedures.
- [ ] Complete all end-to-end tests with separate listener, artist and administrator accounts.
