# Living Music Hub Studio — current build status

## Implemented in this update
- Two-octave C3–C5 piano with white and black keys.
- Four synthesized drum pads and a 16-step sequencer with 70–160 BPM tempo control.
- Live mixer for microphone, keyboard, drums and master output.
- Master recording with elapsed-time display, WAV conversion, preview, download and attach-to-upload action.
- Separate recording destinations for vocals, piano and drums. Each track can be armed independently before recording; armed sources are captured as separate WAV takes.
- Per-take playback, download and delete controls.
- Save/reopen of tempo, sequencer pattern and audio takes using IndexedDB on the current device/browser.
- Service-worker cache version advanced so updated studio assets can replace older cached files.

## Still outstanding
- A visual multitrack timeline with clip positioning, drag/move and non-destructive trim handles.
- Independent post-recording track mixer with mute/solo/pan, plus automation.
- Per-track effects (reverb, delay/echo and EQ) and master processing.
- Cloud project backup/sync; current project saves are local to one browser/device.
- Optional imported audio tracks and final multitrack mixdown from saved clips.

## Important limitations
- This is a browser-based studio, not a desktop DAW. Recording requires a supported browser; microphone access requires HTTPS (or localhost during development) and user permission. Headphones are recommended.
- The WAV encoder currently exports 22.05 kHz mono. Long recordings consume device memory and storage; keep takes short during early testing.
- Actual microphone permission, codec support, audio quality and Android performance still require a physical Android Chrome test after HTTPS hosting. Code checks cannot certify hardware recording.
