# Publish Living Music Hub with GitHub Pages

This project is a static, mobile-first PWA. GitHub Pages can host it over HTTPS at no hosting charge. A custom domain is optional and can be connected later.

## Before publishing

- Keep `config.js` limited to the Supabase project URL and publishable key. Never add a Supabase secret/service-role key.
- Keep public artist uploads closed until the owner account, admin moderation, policies and end-to-end tests are complete.
- This deployment workflow publishes the website files from the repository's `main` branch.

## One-time setup

1. Sign in to GitHub and create a new **public** repository named `living-music-hub` (or choose another name). Do not initialize it with a README, license or `.gitignore` because this package already contains the project files.
2. Upload the contents of this project folder to the repository's root. Ensure `index.html`, `app.js`, `studio.js`, `config.js`, `styles.css`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `.nojekyll` and `.github/workflows/deploy-pages.yml` are at the paths shown in this package.
3. Commit the files to the `main` branch.
4. In the repository, open **Settings → Pages**. Under **Build and deployment → Source**, select **GitHub Actions**.
5. Open the **Actions** tab. The workflow named **Deploy Living Music Hub to GitHub Pages** should run after the commit. Wait for it to complete successfully.
6. Open **Settings → Pages** and follow the published site URL. It will normally be `https://YOUR-GITHUB-USERNAME.github.io/living-music-hub/`.

## Connect Supabase Auth to the published URL

After the final URL is known:

1. Open Supabase Dashboard → Authentication → URL Configuration for project `bflcfrjpvbrlytvjxdlu`.
2. Set **Site URL** to the exact published HTTPS URL.
3. Add the exact URL (and any required redirect pattern for that repository path) to **Redirect URLs**.
4. Save, then test sign-up, email confirmation, sign-in and password reset.

Do not guess the URL before the GitHub username and repository name are confirmed.

## Verify the live website

- Open the URL in Android Chrome.
- Confirm the home page and navigation load over HTTPS.
- Test Discover, search, sign-in and published-song playback.
- Install the PWA from Chrome's menu.
- Open Studio and test piano, drum pads, sequencer and microphone permission with headphones.
- Confirm recordings can be previewed/exported and test artist upload only after moderation is ready.

## Important limitations

A successful GitHub Pages deployment publishes the frontend only. It does not create the owner account, grant administrator rights, change Supabase Auth URLs, or prove that microphone recording and uploads work on a physical phone. Those are separate setup and test steps.
