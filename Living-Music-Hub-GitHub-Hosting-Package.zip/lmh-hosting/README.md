# Living Music Hub

A mobile-first, installable music discovery platform connected to the existing Living Music Hub Supabase project.

## Implemented

- Supabase email sign-up, sign-in, sign-out and password reset.
- Listener and artist profiles.
- Cloud audio uploads into a private storage bucket (50 MB limit).
- Copyright/permission declaration on every submission.
- Moderated song catalogue: pending songs are private; only approved/published songs appear publicly.
- Search and genre filters for published music.
- Streaming through short-lived signed URLs.
- Account-based favourites and listening history.
- Protected moderation queue for users already listed in `public.admin_users`.
- PWA install prompt, service worker and mobile layout.
- Browser music studio: microphone capture, a playable two-octave piano with white and black keys, synthesized drum pads, a 16-step beat sequencer, BPM control, live channel mixer, recording timer, WAV preview and export.
- The live master mix can be exported as a 22.05 kHz mono WAV for upload.
- Multitrack capture records armed vocal, piano and drum sources into separate WAV takes; each take can be previewed, downloaded or deleted.
- Studio projects (tempo, sequencer pattern and track takes) can be saved and reopened in the browser IndexedDB on the same device.

## Supabase project

The app is configured with the project's public API URL and publishable key in `config.js`. The publishable key is designed for browser use and is protected by database Row Level Security. **Never put a secret/service-role key in browser code or commit one to this folder.**

The database already contains `profiles`, `artist_profiles`, `songs`, `favorites`, `play_events`, `playlists`, `playlist_songs` and `admin_users`. The launch-readiness migration was applied directly to the linked project. A copy is in `supabase/living_music_hub_launch_readiness.sql`.

## Run locally

Use a local web server (ES modules and service workers do not work reliably from `file://`):

```bash
python -m http.server 8000
```

Open `http://localhost:8000` in a modern browser. Internet access is required for Supabase and the Supabase JS library CDN. For PWA installation, use HTTPS in production or localhost during development.

## Before public launch

1. In Supabase Authentication → URL Configuration, set the final HTTPS site URL and allowed redirect URLs.
2. Create your owner account through the website's sign-up form and confirm the email if email confirmation is enabled.
3. Promote that account to administrator only after verifying its Auth user UUID. Use the secure owner-only SQL instruction in `PUBLIC-LAUNCH-GUIDE.md`.
4. Deploy this folder to an HTTPS static host and connect a domain you control.
5. Test the studio on Android Chrome over HTTPS with microphone permission and headphones: two-octave piano (including black keys), drum pads, beat sequencing, mixer sliders, recording timer, separate armed-track capture, mixed WAV capture, per-track preview/download/delete, project save/reopen, and upload attachment.
6. Test with separate listener, artist and admin accounts, including pending audio privacy and published playback.
7. Publish privacy, terms, artist upload agreement and copyright/takedown contact details before accepting public submissions.

## Important

The Supabase backend is live and the frontend is now connected in this package, but the website is **not yet publicly hosted**. No domain or hosting provider has been configured. Public uploads should remain closed until admin ownership, email settings, legal pages and end-to-end tests are complete.

## GitHub Pages hosting

A ready-to-use GitHub Actions deployment workflow is included at `.github/workflows/deploy-pages.yml`. Follow `DEPLOY-TO-GITHUB-PAGES.md` to publish this static PWA over HTTPS. GitHub Pages hosting can be used without buying a domain; a custom domain can be connected later. The frontend is not live until the repository is created, the files are committed to `main`, Pages is set to use GitHub Actions, and the deployment workflow succeeds.
