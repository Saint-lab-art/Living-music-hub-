# Living Music Hub

Mobile-first installable music discovery website prototype for Zambia, Africa and worldwide audiences.

## Current prototype

Run locally with `python -m http.server 8000`, then open `http://localhost:8000` in a browser. The current front end supports local song upload/playback, search, genre filtering and favourites. Local uploads remain in the current browser/device only.

## Online launch foundation

See [PUBLIC-LAUNCH-GUIDE.md](PUBLIC-LAUNCH-GUIDE.md) and `supabase/schema.sql` for the Supabase database, authentication-linked artist profiles, moderated catalogue, favourites, access policies and cloud audio storage setup.

**The current website is not yet wired to Supabase or deployed.** Creating a Supabase project and running the SQL does not by itself make the existing local demo upload songs to the internet. The sign-in and cloud-upload integration, moderation dashboard, legal pages and hosting configuration still need to be completed and tested.

Never place a Supabase `service_role` secret in browser code. Only use the public publishable/anon key in a client app with Row Level Security enabled.
