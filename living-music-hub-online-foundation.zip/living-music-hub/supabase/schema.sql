-- Living Music Hub: Supabase starter schema
-- Run in Supabase Dashboard > SQL Editor on a NEW project.
-- Public tracks are visible only after an administrator sets status='published'.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Artist',
  country text not null default 'Zambia',
  bio text not null default '',
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.tracks (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  genre text not null default 'Other',
  country text not null default 'Zambia',
  audio_path text not null,
  cover_url text,
  duration_seconds integer check (duration_seconds is null or duration_seconds >= 0),
  status text not null default 'pending' check (status in ('pending','published','rejected','removed')),
  rights_confirmed boolean not null default false check (rights_confirmed = true),
  created_at timestamptz not null default now(),
  published_at timestamptz
);

create table if not exists public.favourites (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

-- Admin role is assigned manually by the project owner in the SQL editor.
create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','moderator'))
);

create or replace function public.is_music_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = auth.uid() and role in ('admin','moderator')); $$;
revoke all on function public.is_music_admin() from public;
grant execute on function public.is_music_admin() to authenticated;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'display_name',''), split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.tracks enable row level security;
alter table public.favourites enable row level security;
alter table public.user_roles enable row level security;

drop policy if exists "Profiles are publicly readable" on public.profiles;
create policy "Profiles are publicly readable" on public.profiles for select using (true);
drop policy if exists "Users create own profile" on public.profiles;
create policy "Users create own profile" on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "Published tracks are public" on public.tracks;
create policy "Published tracks are public" on public.tracks for select using (status = 'published' or artist_id = auth.uid() or public.is_music_admin());
drop policy if exists "Artists submit own tracks" on public.tracks;
create policy "Artists submit own tracks" on public.tracks for insert to authenticated with check (artist_id = auth.uid() and status = 'pending' and rights_confirmed = true);
drop policy if exists "Artists edit own pending tracks" on public.tracks;
create policy "Artists edit own pending tracks" on public.tracks for update to authenticated using (artist_id = auth.uid() and status = 'pending') with check (artist_id = auth.uid() and status = 'pending' and rights_confirmed = true);
drop policy if exists "Admins moderate tracks" on public.tracks;
create policy "Admins moderate tracks" on public.tracks for update to authenticated using (public.is_music_admin()) with check (public.is_music_admin());

drop policy if exists "Users see own favourites" on public.favourites;
create policy "Users see own favourites" on public.favourites for select to authenticated using (user_id = auth.uid());
drop policy if exists "Users add own favourites" on public.favourites;
create policy "Users add own favourites" on public.favourites for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users remove own favourites" on public.favourites;
create policy "Users remove own favourites" on public.favourites for delete to authenticated using (user_id = auth.uid());

drop policy if exists "Users cannot read role table" on public.user_roles;
create policy "Users cannot read role table" on public.user_roles for select to authenticated using (user_id = auth.uid() and public.is_music_admin());

-- Public bucket enables streaming of approved audio. Uploads are restricted to
-- an authenticated user's own folder: <auth.uid()>/<random-file-name>.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('music-audio', 'music-audio', true, 52428800, array['audio/mpeg','audio/mp4','audio/aac','audio/wav','audio/ogg','audio/flac'])
on conflict (id) do update set public = true, file_size_limit = 52428800,
  allowed_mime_types = array['audio/mpeg','audio/mp4','audio/aac','audio/wav','audio/ogg','audio/flac'];

drop policy if exists "Artists upload to own folder" on storage.objects;
create policy "Artists upload to own folder" on storage.objects for insert to authenticated
with check (bucket_id = 'music-audio' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Artists update own audio" on storage.objects;
create policy "Artists update own audio" on storage.objects for update to authenticated
using (bucket_id = 'music-audio' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'music-audio' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Artists delete own audio" on storage.objects;
create policy "Artists delete own audio" on storage.objects for delete to authenticated
using (bucket_id = 'music-audio' and (storage.foldername(name))[1] = auth.uid()::text);
-- Public playback is enabled by the bucket setting; never expose a service-role key in the browser.

-- After creating your own account, promote it to admin by replacing the UUID below:
-- insert into public.user_roles(user_id, role) values ('YOUR-AUTH-USER-UUID','admin');
