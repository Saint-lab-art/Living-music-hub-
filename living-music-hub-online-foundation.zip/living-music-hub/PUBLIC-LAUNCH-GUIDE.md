# Living Music Hub — online launch foundation

This package adds a Supabase database/storage foundation to the mobile website prototype. It is **not yet connected to a live Supabase project** and it has not been deployed publicly. No account credentials or domain were supplied.

## What the foundation provides

- Artist profiles linked to authenticated accounts.
- Track catalogue with moderation states: pending, published, rejected, removed.
- Favourites per listener account.
- Row Level Security policies so artists can submit tracks only for themselves and public visitors can read only published tracks.
- A `music-audio` cloud storage bucket with a 50 MB upload limit and per-user upload folders.
- Admin/moderator role table for moderation access.

## Step-by-step setup

1. Create a Supabase project at https://supabase.com/dashboard. Choose a strong database password and keep it private.
2. In the project, open **SQL Editor**, create a new query, paste all of `supabase/schema.sql`, and run it.
3. Open **Project Settings → API** (or **Connect**) and copy the Project URL and the publishable/anon public key. Do not copy or expose the `service_role` secret.
4. Configure Authentication → URL Configuration with the final website URL and its allowed redirect URLs. For initial testing, use the local development URL only if Supabase permits it; production must use HTTPS.
5. Create a test artist account after the future sign-in screen is connected. The SQL trigger creates a profile automatically.
6. To appoint the platform owner as admin, find that user's UUID in Authentication → Users, then run the final commented `insert into public.user_roles...` statement in the SQL file with that UUID. Do not make unknown users administrators.
7. Deploy the website to an HTTPS host such as Netlify, Vercel or Cloudflare Pages and connect a domain you own.
8. Before accepting public uploads, finish and test the account/sign-in, cloud upload, streaming, artist dashboard, admin moderation, takedown and reporting flows described below.

## Important: the current website is still a local demo

The existing `app.js` stores uploaded audio in the browser's IndexedDB. The SQL schema creates the cloud backend, but the website does not yet call Supabase. Do not advertise local-demo uploads as public submissions. A subsequent integration step must replace local-only upload/list/play operations with authenticated Supabase calls.

## Required integration work before public launch

- Add sign-up, sign-in, sign-out, password reset and profile editing.
- On upload, require authentication, upload audio to `music-audio/<user-id>/<random-file-name>`, then insert a `tracks` row with `status='pending'` and `rights_confirmed=true`.
- Public catalogue/search must query only `status='published'` tracks. Use the bucket's public URL for playback after moderation.
- Build a protected moderation dashboard for admins to publish/reject/remove submissions and handle copyright complaints.
- Add rate limits, file validation beyond MIME type, malware scanning, abuse reporting, privacy/terms pages, backups and monitoring.
- Add an artist takedown request process and retain evidence of upload rights/permissions.
- Test RLS using separate listener, artist and admin accounts before release.

## Copyright and safety

Artists must confirm that they own the recording or have all permissions needed to distribute it. Create a clear copyright complaint/takedown process and artist agreement. Obtain appropriate legal advice for Zambian copyright, privacy/data protection, consumer and tax obligations. Do not upload commercial recordings without permission.

## Deployment readiness checklist

- [ ] Supabase project created and SQL executed
- [ ] Authentication configured and tested
- [ ] Admin account assigned securely
- [ ] Website connected to Supabase (not yet implemented in this prototype)
- [ ] Cloud upload, published-only playback and search tested
- [ ] Moderation and takedown process tested
- [ ] Privacy policy, terms and artist agreement approved
- [ ] Domain and HTTPS configured
- [ ] Android/PWA install tested on real devices

## Hosting options

- Netlify: https://www.netlify.com/
- Vercel: https://vercel.com/
- Cloudflare Pages: https://pages.cloudflare.com/
- Supabase: https://supabase.com/
